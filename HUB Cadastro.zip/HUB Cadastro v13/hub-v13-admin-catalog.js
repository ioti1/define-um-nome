/* Um editor expandido por catálogo. Recolher nunca remove campos nem rascunhos. */
const portalCatalogHost = document.getElementById('adminPortalItems');
function resizePortalCatalog(){ portalCatalogHost?.style.setProperty('--catalog-rows',String(Math.max(1,portalCatalogHost.querySelectorAll('.portal-edit-row').length))); }
if(portalCatalogHost){ new MutationObserver(resizePortalCatalog).observe(portalCatalogHost,{childList:true}); resizePortalCatalog(); }
document.addEventListener('toggle',event => {
  if(typeof sharedPublicationBusy !== 'undefined' && sharedPublicationBusy) return;
  const item = event.target;
  if(!item.open || !adminModal.classList.contains('authenticated')) return;
  const isEvent = item.matches('#adminEventItems > .calendar-admin-row');
  const isShortcut = item.matches('#adminPortalItems > .portal-edit-row > details.admin-more');
  if(!isEvent && !isShortcut) return;
  const host = document.getElementById(isEvent ? 'adminEventItems' : 'adminPortalItems');
  const selector = isEvent ? ':scope > .calendar-admin-row[open]' : ':scope > .portal-edit-row > details.admin-more[open]';
  host.querySelectorAll(selector).forEach(other => { if(other !== item) other.open = false; });
  (isEvent ? item : item.closest('.portal-edit-row')).scrollIntoView?.({block:'nearest'});
},true);
document.getElementById('adminAgents')?.addEventListener('change',event => {
  if(sharedPublicationBusy || !adminModal.classList.contains('authenticated') || state.adminMode !== 'agents' || !event.target.matches('.agent-variant')) return;
  aiAgents = collectAdminAgents(); saveAppsLocal(); renderAgents();
  adminMessage.textContent = 'Estilo atualizado na prévia local. Publique para compartilhar.';
});
document.getElementById('adminEventItems')?.addEventListener('change',event => {
  if(sharedPublicationBusy || !portalCalendarAdminAllowed() || !event.target.matches('.event-field-color')) return;
  collectPortalEventsDraft(false); saveAppsLocal(); renderPortalCalendar();
  adminMessage.textContent = 'Cor atualizada na prévia local. Publique para compartilhar.';
});

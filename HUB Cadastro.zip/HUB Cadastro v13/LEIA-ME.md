# HUB Cadastro v13

Portal local do Setor de Cadastro. Não usa servidor: o HTML, a configuração e a Base de Apoio funcionam juntos na mesma pasta.

Na Central de Aplicações, **Abrir** inicia a ferramenta diretamente em uma nova aba. **Detalhes** abre a ficha completa com documentação, ambiente, versão, segurança e histórico.

## Arquivos essenciais

- **HUB Cadastro v13.html** — aplicação principal;
- **hub-v13.css** — estilo visual;
- **hub-v13-admin.js** — administração segmentada;
- **hub-v13-admin-workspace.css** e **hub-v13-admin-workspace.js** — área administrativa em tela cheia, organização e navegação;
- **hub-v13-dashboard.css** — catálogo em grade à esquerda e quatro quadros empilhados à direita;
- **hub-v13-compact.css** e **hub-v13-compact.js** — cards compactos, títulos externos, links em duas colunas e agenda no cabeçalho;
- **hub-v13-admin-catalog.css** e **hub-v13-admin-catalog.js** — catálogos recolhidos, prévias de cores e refinamento dos quadros;
- **hub-v13-portal.js** — links, documentos rápidos e consulta de notícias;
- **hub-v13-app-rail.css** e **hub-v13-app-rail.js** — faixa horizontal dos acessos rápidos;
- **hub-v13-panels.css** — quatro quadros alinhados e estilo do calendário;
- **hub-v13-events.js** — calendário e cadastro manual dos eventos;
- **hub-cadastro-config.js** — fonte compartilhada carregada automaticamente pelo HUB;
- **hub-cadastro-config.json** — espelho legível, backup e arquivo de importação;
- **Base de Apoio** — PDFs, Word, Excel, manuais e outros conteúdos exibidos na Central de Apoio.
- **assets** — panorama local do Rio; mantenha esta pasta junto ao HTML.

## Novo visual

**Ajuste de espaços:** Acessos rápidos não estica mais para acompanhar a altura da coluna direita. Filtros ficam à direita em telas grandes e à esquerda na linha própria em notebooks. Notícias, links e documentos usam altura conforme o conteúdo, com rolagem interna apenas após o limite (235 px de conteúdo para notícias; 180 px para atalhos). O rodapé das fontes acompanha a lista, sem espaço vazio artificial. Linhas dos atalhos separam fileiras por cima, sem sublinhados soltos na última fileira incompleta.

Cabeçalho com a arte enviada pelo usuário, texto sobre área clara e composição limitada a 1920 px para evitar ampliação excessiva em monitores ultrawide. A transição já faz parte da imagem; não há curvas artificiais sobrepostas. O tema escuro tem base grafite, com textos claros e acentos azul-Petros.

Aplicações sem fotografias: ícone vetorial, nome, resumo em até quatro linhas, situação e Abrir/Detalhes. A composição segue a nova referência: catálogo à esquerda, com quatro cards por linha a partir de 1500 px; à direita, Previdência em pauta, Links úteis, Documentos rápidos e Próximos eventos empilhados. Em telas intermediárias, a grade reduz para três ou duas colunas. Abaixo de 900 px, os quadros ficam abaixo do catálogo, em duas colunas; no celular, em uma. O resumo completo continua em Detalhes. Produção, Homologação e Indisponível/Em desenvolvimento são situações configuradas pelo administrador, não um teste em tempo real da conexão.

O catálogo usa a rolagem normal da página; a antiga faixa horizontal está desativada nesta composição. Use Tab para acessar favoritos e Abrir/Detalhes. A visualização em lista permanece disponível, com estrela de favorito nos dois modos. Busca, filtros e ordenação são os mesmos. O hero e a área administrativa não foram alterados nesta mudança de layout.

Os agentes ficam em bolinhas empilhadas na lateral direita da fotografia, junto à parte inferior: ao passar o mouse ou focar pelo teclado, expandem para a esquerda com nome e subtítulo; clicar abre diretamente o agente em nova aba. Agentes adicionais usam rolagem vertical dentro do banner. No celular, as bolinhas mantêm acesso direto e não expandem sobre o texto. A tela de todos os agentes continua disponível no menu de pontos do cabeçalho. Nenhum card ocupa o espaço dos aplicativos.

As configurações existentes foram preservadas: nenhum link, agente, documento ou regra de publicação foi substituído. Para manter os caminhos relativos das aplicações, coloque o HTML, todos os CSS/JS v13 e a pasta assets no mesmo diretório em que já ficam o HUB e seus arquivos de configuração. Se houver uma configuração publicada mais recente, mantenha seu JSON e JS atuais.

O novo banner está em **assets/rio-banner.png**, cópia da imagem fornecida. A imagem anterior permanece no pacote apenas como referência. Os ícones são vetoriais e funcionam offline.

A marca do canto superior esquerdo usa os PNGs fornecidos: **assets/logo-petros-claro.png** no tema claro e **assets/logo-petros-escuro.png** no escuro. A troca acompanha automaticamente o tema selecionado, inclusive ao reabrir o HUB. A largura é de 146 px no desktop e 120–128 px nas telas menores, sem texto ou símbolo desenhado por cima.

Mantenha o nome **hub-cadastro-config.js**. É esse arquivo que permite que cada pessoa abra o HUB e receba a configuração publicada sem selecionar nada.

## Configurar os novos quadros

Após a senha, o Admin ocupa toda a página, com navegação lateral, cabeçalho e publicação separados dos painéis roláveis. Em telas pequenas, a navegação passa a uma faixa horizontal. São oito seções: Aplicações, Agentes de IA, Links úteis, Documentos rápidos, Calendário e eventos, Central de Apoio, Notícias e Importar e backup.

Em Aplicações, busque e selecione o item na lista lateral. O campo Rótulo curto define o resumo do card; quando vazio, usa a descrição existente. Detalhes extensos ficam na ficha. O seletor Posição permite mover diretamente para qualquer lugar; Anterior/Seguinte ajustam um passo. Favoritos e ordenação alfabética na consulta podem ter prioridade sobre essa ordem. A exclusão fica no fim do próprio formulário, com confirmação.

Agentes, links e documentos também têm um seletor direto de posição. Links e documentos apresentam um resumo, com Editar dados expansível para não alongar desnecessariamente a lista. Podem ter URL, arquivo local ou caminho relativo, ícone e descrição. Documentos também podem apontar a uma referência já cadastrada na Central de Apoio.

Em Importar e backup, exporte o rascunho como JSON antes de operações importantes. Importar JSON, restaurar o padrão e excluir itens alteram somente o rascunho: revise e use Publicar para todos para efetivar na configuração compartilhada. Cancelar uma confirmação não altera os dados. A importação prepara todas as seções antes de aplicar o conteúdo; erros de leitura são informados. Ao sair do Admin, os campos são recolhidos para o cache local; se esse cache falhar, a edição permanece aberta para permitir exportação. Ao reabrir o HUB, a configuração compartilhada tem prioridade: exporte rascunhos ainda não publicados antes de fechar/recarregar.

Use Publicar para todos: links, documentos, calendário e preferências de notícias entram no objeto portal do mesmo JSON/JS compartilhado. Os quadros começam vazios para não inventar atalhos ou eventos da equipe. Nenhum usuário de consulta precisa selecionar JSON.

Na revisão compacta, os títulos ficam acima das caixas de notícias, links e documentos. Fonte e data da notícia compartilham uma linha, com identificação de cache quando aplicável. Links úteis usam duas colunas, com quebra de nomes longos e rolagem interna. Os cards de aplicações têm altura e ícones menores, sem o grande espaço vazio anterior; Abrir, Detalhes e favoritos permanecem disponíveis.

A busca principal fica à esquerda, após a marca. Próximos eventos é uma faixa sempre visível ao lado da busca: até quatro eventos por ordem de data e hora, com formato DD/MM – Título e horário/local quando preenchidos. O número exibido acompanha a largura disponível (máximo quatro e respeitando o limite do Admin); em telas menores, a faixa passa para uma linha própria. O título completo, descrição e informações complementares ficam no tooltip; links configurados abrem em nova aba. Sem eventos, aparece uma mensagem honesta, sem exemplos inventados. A edição continua em Admin → Calendário e eventos, no mesmo JSON/JS; alterações e passagem do horário atualizam a faixa. A última publicação fica no tooltip do título da agenda.

Os títulos dos quadros de notícias, links e documentos ficam integrados ao topo das caixas, com ícones discretos e distância reduzida até o conteúdo, seguindo a referência mais recente. Não há uma faixa de título isolada longe da caixa.

Os cabeçalhos de Links úteis, Documentos rápidos e Próximos eventos não possuem botão Configurar: toda edição continua nas seções correspondentes do Admin. O botão de atualização das notícias permanece disponível.

## Calendário e eventos

1. Entre no **Admin → Calendário e eventos**.
2. Clique em **Adicionar evento** e informe título e data. Horários inicial/final, local, categoria, descrição, cor, situação e link/arquivo são opcionais.
   Os campos essenciais ficam compactos; local, categoria, descrição e link ficam em Informações complementares. O editor e a consulta ordenam por data e hora, sem controles de ordem manual.
3. Ajuste o título do quadro e o limite da lista (1–12 eventos). A tela inicial exibe somente os próximos eventos, sem calendário mensal.
4. Clique em **Publicar para todos**. A agenda é salva em `portal.calendar` no mesmo JSON/JS, sem arquivo extra de dados.

Na consulta, a lista apresenta os próximos eventos por data e horário. Eventos passados, encerrados ou cancelados não aparecem nessa lista. Sem horário, o evento permanece durante o dia inteiro; com início/fim, permanece até o fim. A lista se atualiza conforme o relógio local, sem necessidade de recarregar. Configurações antigas com `showCalendar:true` também abrem somente em lista: o campo legado é mantido como `false`, sem excluir eventos já cadastrados.

A linha de apoio mostra **Última atualização: DD/MM, HH:mm · Responsável**, usando `updatedAt` e `updatedBy` da última publicação compartilhada do HUB — não o horário de abertura, um rascunho ou um nome de exemplo. O horário da publicação usa o fuso de São Paulo; as datas dos eventos continuam seguindo o calendário local. A linha é atualizada imediatamente após uma publicação confirmada, mas não avança quando ela falha. Configurações sem data válida mostram **Última atualização: não informada**; sem autoria, **responsável não informado**. O nome vem do responsável informado pelo administrador no fluxo de publicação, sem identificação automática da pessoa conectada ao computador. Nenhum campo novo ou dado fictício é adicionado ao JSON/JS.

Datas seguem o calendário local do usuário, sem conversão UTC que possa alterar o dia. A agenda aceita até 300 eventos; registros antigos ficam no Admin para consulta, edição ou remoção. Descrições preservam quebras de linha. Links abrem em nova aba. A cor identifica visualmente o evento; data e horário também são escritos, não dependem somente da cor.

Rascunhos incompletos são mantidos ao trocar de seção, mas uma data inválida, horário final anterior ao inicial, link inseguro ou evento sem título bloqueia a publicação, inclusive quando outra ação tenta salvar a configuração. Alterações ainda não publicadas ficam apenas na sessão/cache local; quem abre o HUB recebe a última agenda publicada. Não há integração com Outlook, Google ou notícias: todos os eventos são preenchidos à mão pelo administrador.

Depois de adotar a v13, faça as publicações administrativas por esta versão. Os administradores de versões antigas não conhecem os novos quadros e podem removê-los ao republicar uma configuração.

No cabeçalho, o menu de pontos abre Aplicações, Agentes, Apoio e Ajuda. A busca filtra aplicações; Enter ou Ctrl+K abre a busca global, incluindo referências e atalhos do painel. O sino leva ao quadro de notícias; a engrenagem abre o Admin.

## Notícias e acesso à internet

Por padrão, o navegador consulta diretamente os índices públicos da Agência Brasil sobre Previdência Social, Previdência Complementar, INSS e Aposentadoria, junto à API pública oficial da InfoMoney. A segunda consulta usa as tags Previdência, Previdência Privada, Previdência Complementar e Previdência Complementar Fechada. Títulos são filtrados por assunto, deduplicados e ordenados pela data publicada; o quadro exibe as três mais recentes **entre os resultados obtidos**, com fonte, data e hyperlink. Não significa as três últimas notícias de toda a internet nem uma matéria obrigatória de cada fonte.

No **Admin → Notícias**, selecione **Fontes públicas — previdência (automática)** e escolha **Consultar também a InfoMoney** ou **Somente Agência Brasil**. A opção entra em `portal.news.includeInfoMoney` no mesmo JSON/JS quando você usa **Publicar para todos**. Configurações anteriores sem esse campo recebem a InfoMoney habilitada por padrão. O modo RSS personalizado continua independente; não mistura a InfoMoney automaticamente.

A consulta InfoMoney usa `/wp-json/wp/v2/posts` com IDs públicos das tags, no máximo 12 registros e somente link/título/datas. O endpoint não inclui todo tipo editorial: rotas de colunistas e conteúdos patrocinados não são agregadas. Títulos são convertidos de HTML para texto e escapados; `date_gmt` é interpretada como UTC e exibida na data local. Somente links HTTPS do domínio InfoMoney são aceitos. Não são copiados os textos completos dos artigos.

As fontes verificadas permitem CORS para arquivos locais. Isso pode mudar, e rede corporativa pode bloquear o acesso. Sem internet ou em caso de falha, o quadro exibe a última consulta salva com identificação de cache, ou um estado vazio honesto no primeiro acesso. Se só uma fonte falhar, a outra continua sendo consultada; a mensagem identifica a falha parcial. Notícias já salvas da fonte que falhou podem ser reaproveitadas, com **em cache** ao lado do nome. O cache é individual no navegador, separado da configuração compartilhada; dura 15 minutos antes de uma nova consulta no próximo acesso. O botão ↻ força atualização. O cache anterior da Agência Brasil permanece disponível offline, mas não impede a primeira consulta online à InfoMoney.

Notícias podem ser desativadas ou usar RSS/Atom HTTPS sem credenciais no Admin. A fonte personalizada também precisa permitir CORS. Nenhum servidor ou proxy foi criado. O HTML remoto não é inserido na tela; somente títulos, datas e links validados são renderizados. Não há notícias fictícias.

**Por que API e não RSS da InfoMoney?** Em 01/10/2026, os feeds oficiais responderam HTTP 200, mas `Access-Control-Allow-Origin` permitia somente `https://www.infomoney.com.br`, não o HTML local. A API oficial respondeu HTTP 200 JSON com `Access-Control-Allow-Origin: null`, compatível com `Origin: null` de arquivos locais. As consultas usam GET simples, sem credenciais ou cabeçalhos personalizados. Essas políticas podem mudar; a verificação dos cabeçalhos não garante liberação em todas as redes corporativas.

**E o G1?** Não é uma escolha editorial contra o G1. O RSS oficial de Economia (https://g1.globo.com/rss/g1/economia/) respondeu, mas não enviou o cabeçalho Access-Control-Allow-Origin nos testes com Origin:null. O navegador bloqueia sua leitura automática pelo HTML local. A Agência Brasil permitiu essa leitura. Fontes alternativas são possíveis se também liberarem CORS. O G1 pode ser aberto normalmente como link útil, mas não foi incluído na consulta automática nem foi criado um proxy para contornar a restrição. Cabeçalhos e políticas podem mudar.

## Verificações desta entrega

**Catálogos administrativos e cores:** eventos completos ficam em cards recolhidos acima do formulário; eventos novos/incompletos abrem para preenchimento. Clique em Editar / expandir para revisar um existente. Links e documentos mostram os itens cadastrados à esquerda e o formulário expandido à direita em telas grandes; em telas pequenas, a lista fica acima do editor. Só um formulário fica expandido por catálogo. Recolher preserva todos os campos, inclusive os rascunhos ainda não publicados; excluir fica dentro do editor. Essa lista representa o rascunho atual, não uma confirmação de publicação. Eventos continuam ordenados por data e horário.

Os quadros de notícias, links e documentos foram ampliados. Links usam três colunas em telas largas e duas quando o espaço diminui; documentos usam três no desktop amplo e duas nas telas menores. O título Acessos rápidos e seus filtros ficam alinhados à esquerda nos notebooks. A faixa de eventos respeita os marcadores verde, azul, dourado e violeta, inclusive no tema escuro. Os agentes respeitam o estilo claro/escuro de cada registro, sem depender de sua posição. Alterar essas escolhas no Admin atualiza a prévia local; use Publicar para todos para compartilhar. Seis testes adicionais de código/VM verificam o renderizador real dos agentes, eventos recolhidos, preservação dos campos, cores e integridade da configuração. A conferência visual renderizada no navegador permanece pendente.

**Revisão compacta:** sete novos testes de código/DOM simulado verificam títulos externos sem perda dos nós originais, agenda única no cabeçalho, fechamento por clique externo/Escape com retorno de foco, fonte/data/cache das notícias, links em duas colunas, cards menores e agentes verticais à direita. A agenda agora fica no cabeçalho, deixando três quadros na coluna lateral. O JSON/JS de dados, autenticação, publicação e edição dos eventos foram preservados. Inspeção visual renderizada no navegador permanece pendente.

**Composição com painéis laterais:** oito grupos adicionais verificam a nova grade, os quatro quadros empilhados, a desativação dos controles de faixa horizontal, preservação exata do hero/Admin/dados, estados de lista, responsividade, tema escuro e movimento reduzido. As regressões de agenda, publicação, Admin, favoritos e notícias foram reexecutadas. São testes de código e DOM simulado: a inspeção visual renderizada no navegador permanece pendente. Os relatos abaixo também registram validações das versões anteriores, incluindo a antiga faixa horizontal.

Testados sintaxe e integração dos scripts/IDs, leitura da configuração anterior, serialização JSON/JS, isolamento dos formulários, autenticação e seleção de seção, busca/filtros, cards e abertura em nova aba. O quadro de notícias passou por 21 testes com fixtures (parsing, datas, ordem, URLs, cache, indisponibilidade e concorrência). A revisão v13 acrescentou 8 grupos de testes para dock, cards, integridade dos arquivos e regras responsivas de 360 a 3440 px. Foram verificados 11 novos pares sólidos de cores, além dos 32 pares anteriores, com contraste de texto mínimo de 4,5:1. Isso não mede cada pixel da fotografia.

A faixa horizontal passou por 10 grupos adicionais com 0, 1, 7 e 30 cards, navegando por setas/teclado/roda, limites, filtros, lista, mudanças de tamanho e movimento reduzido. O CSS principal, os estilos existentes da faixa e os arquivos de configuração foram preservados; o favorito da lista recebeu um ajuste isolado, e somente o quadro institucional do hero foi retirado. Esses testes usam código e DOM simulado, não uma página renderizada.

A agenda em lista passou por 24 grupos adicionais: datas locais/anos bissextos, lista futura, limite, cancelamentos, atualização pelo relógio, proteção do foco, edição autenticada, troca de seção sem perda de rascunho, escape de texto, links, importação e publicação compartilhada. A publicação é protegida tanto no salvamento geral quanto na escrita/baixamento dos arquivos. A cascata estática de 4/2/1 quadros e os pares de contraste das datas foram verificados; todos atingiram pelo menos 4,5:1. Os testes de Admin, notícias e faixa horizontal também foram reexecutados. Favoritos na lista passaram por mais 7 grupos de clique, persistência, troca de modo, ações independentes e cascata responsiva nas duas cores.

As fontes da Agência Brasil retornaram HTTP 200 e CORS * em testes de rede com Origin:null; o RSS do G1 retornou 200 sem esse cabeçalho. Isso não elimina restrições específicas da rede de cada usuário. A inspeção visual em navegador nesta sessão foi limitada pelo bloqueio de automação a file://; testes de código e de contraste não substituem essa etapa.

A integração InfoMoney foi verificada com requisições reais aos endpoints oficiais e testes controlados de parsing JSON, datas UTC, segurança, mesclagem/ordenação, configuração, cache e indisponibilidade parcial. Os testes do restante do HUB foram reexecutados. Não foi executada uma consulta por navegador local nesta sessão.

## Publicar alterações

1. Abra o HTML e entre no **Admin**.
2. Edite a seção desejada, incluindo Calendário e eventos.
3. Clique em **Publicar para todos**.
4. No primeiro uso administrativo, selecione esta pasta — a mesma que contém o HTML.

O HUB grava e confere **hub-cadastro-config.json** e **hub-cadastro-config.js** em conjunto. Nos próximos usos, o navegador tenta reutilizar a autorização.

### Proteção da publicação — atualização de 01/10/2026

- Enquanto publica, o botão mostra **Publicando…** e os controles administrativos ficam temporariamente bloqueados. Uma barra informa seis etapas reais: preparação, leitura/conferência, gravação do JSON, gravação do JS, verificação final e confirmação. Não é uma porcentagem de bytes nem uma animação temporizada; o sucesso só aparece após conferir os dois arquivos. Falhas e cancelamentos têm mensagem própria. Uma segunda publicação na mesma aba não é iniciada. Quando disponível em `file://`, Web Locks também protege abas da mesma origem no mesmo navegador/perfil.
- JSON e JS usam uma única cópia dos dados. A revisão e os metadados só avançam depois que os dois arquivos são lidos novamente e conferidos.
- Falhas de leitura não são confundidas com arquivo inexistente ou vazio. Arquivos inválidos ou um JSON/JS divergente interrompem a operação para revisão, sem substituir silenciosamente os dados.
- Erros transitórios de acesso, como `InvalidStateError`, recebem até três tentativas limitadas, com novas referências aos arquivos e conferência antes de repetir. Se o fechamento já tiver efetivado a gravação, o conteúdo confirmado evita uma gravação repetida desnecessária.
- O conteúdo é revalidado antes de concluir cada escrita e entre os dois arquivos. Quando detecta alteração externa, a publicação é interrompida. A restauração só é tentada sobre conteúdo reconhecido como anterior ou pertencente à própria tentativa; alterações externas detectadas não recebem restauração cega.
- Uma falha mantém os dados editados na sessão e informa a etapa e o arquivo envolvidos. Use **Exportar JSON** para guardar seu rascunho **antes de recarregar ou fechar**. A próxima abertura prioriza a configuração compartilhada publicada, não um rascunho local.
- Se o acesso da pasta continuar inválido, a referência administrativa é esquecida para que a próxima tentativa solicite a seleção da pasta novamente. A indexação da Base de Apoio precisa terminar antes da publicação.

**OneDrive e concorrência:** não existe transação atômica entre dois arquivos nem bloqueio distribuído entre computadores nesse modelo HTML local. As verificações reduzem os riscos, mas não eliminam todas as corridas de sincronização. Evite publicar simultaneamente em computadores diferentes e aguarde o OneDrive concluir a sincronização. Não interprete uma mensagem de falha como confirmação de publicação.

O fluxo foi validado com testes controlados de leitura/escrita, erros transitórios e permanentes, gravação com confirmação ambígua, concorrência, restauração, rascunhos e controles administrativos. Os testes não substituem uma execução real do navegador/OneDrive no computador afetado. O layout e os dados de configuração distribuídos não foram alterados nesta correção.

Na refatoração administrativa subsequente, os testes de regressão foram reexecutados, com 14 grupos adicionais para navegação, posições arbitrárias e limites, proteção da autenticação, eventos cronológicos, exclusões locais, rascunhos, backup apesar de falha no cache e etapas de publicação. O layout administrativo e a posição dos agentes foram alterados; o banner, os demais quadros e os arquivos de configuração foram preservados. São verificações de código/DOM simulado, não uma inspeção visual renderizada nem um teste de escrita no OneDrive.

## Atualizar a Base de Apoio

1. Copie os arquivos para as subpastas de **Base de Apoio**.
2. No Admin, abra **Central de Apoio** e clique em **Indexar pasta de apoio**.
3. Revise o catálogo e clique em **Publicar para todos**.

Somente o administrador autoriza a pasta. Quem consulta o HUB recebe o índice pelo arquivo JS e não precisa selecionar documentos ou diretórios.

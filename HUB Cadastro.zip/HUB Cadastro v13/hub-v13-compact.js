/* Reorganização visual. Os nós, IDs e dados originais são preservados. */
(() => {
  'use strict';
  document.querySelectorAll('.portal-panels > .portal-panel').forEach(panel => {
    const heading = panel.querySelector('.panel-head');
    const body = document.createElement('div');
    body.className = 'panel-card-body';
    [...panel.children].filter(child => child !== heading).forEach(child => body.appendChild(child));
    panel.appendChild(body);
  });
  const actions = document.querySelector('.masthead-actions');
  const panel = document.querySelector('.calendar-panel');
  if(!actions || !panel) return;
  const menu = document.createElement('section');
  menu.className = 'header-events';
  menu.setAttribute('aria-label','Próximos eventos do setor');
  menu.innerHTML = '<span class="header-events-label">Próximos eventos</span><div class="header-events-items" id="headerUpcomingEvents"></div>';
  panel.hidden = true;
  menu.appendChild(panel);
  actions.insertBefore(menu,document.getElementById('headerNews'));
  let signature = '';
  function update(){
    const width = menu.getBoundingClientRect().width;
    const count = headerEventCapacity(width);
    const settings = portalCalendarSettings();
    const events = portalCalendarUpcoming(settings.events).slice(0,Math.min(count,settings.maxItems || 6));
    const label = portalCalendarPublicationLabel(typeof configMeta !== 'undefined' ? configMeta : null);
    const next = JSON.stringify([events,count,label,settings.title]);
    if(next === signature) return;
    signature = next;
    const host = document.getElementById('headerUpcomingEvents');
    host.style.setProperty('--event-count',String(Math.max(1,events.length)));
    host.innerHTML = events.length ? events.map(headerEventMarkup).join('') : '<span class="header-event-empty">Nenhum evento futuro agendado</span>';
    menu.title = label;
    menu.querySelector('.header-events-label').textContent = settings.title || 'Próximos eventos';
  }
  new MutationObserver(update).observe(document.getElementById('calendarEvents'),{childList:true});
  new MutationObserver(update).observe(document.getElementById('calendarState'),{childList:true});
  if(typeof ResizeObserver === 'function') new ResizeObserver(update).observe(menu);
  window.addEventListener('resize',update,{passive:true});
  update();
})();

function headerEventCapacity(width){ return Math.min(4,Math.max(1,Math.floor((Number(width) || 160)/155))); }
function headerEventMarkup(event){
  const date = event.date.slice(8,10) + '/' + event.date.slice(5,7);
  const time = event.time ? event.time + (event.endTime ? '–' + event.endTime : '') : '';
  const extra = [time,event.location || event.category].filter(Boolean).join(' · ');
  const description = [date,event.title,extra,event.description].filter(Boolean).join(' — ');
  const content = '<span class="header-event-main"><time datetime="' + h(event.date) + '">' + h(date) + '</time><span aria-hidden="true"> – </span><strong>' + h(event.title) + '</strong></span>' + (extra ? '<small>' + h(extra) + '</small>' : '');
  const url = event.url ? safeResourceUrl(event.url) : '';
  const color = ['teal','blue','gold','purple'].includes(event.color) ? event.color : 'teal';
  return url ? '<a class="header-event" data-color="' + color + '" href="' + h(url) + '" target="_blank" rel="noopener noreferrer" title="' + h(description) + '">' + content + '</a>' : '<span class="header-event" data-color="' + color + '" tabindex="0" title="' + h(description) + '">' + content + '</span>';
}

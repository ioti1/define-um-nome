/* Navegação local: sem alteração de dados, sem rolagem automática por hover. */
(() => {
  'use strict';
  const grid = document.getElementById('appGrid');
  const controls = document.getElementById('appRailControls');
  const previous = document.getElementById('appRailPrev');
  const next = document.getElementById('appRailNext');
  if (!grid || !controls || !previous || !next) return;
  // A grade com painéis laterais usa rolagem normal da página, não a faixa horizontal.
  if (grid.dataset?.layout === 'dashboard') { controls.hidden = true; return; }
  const reduced = typeof window.matchMedia === 'function' ? window.matchMedia('(prefers-reduced-motion: reduce)') : {matches:true};
  let frame = null;
  const limit = () => Math.max(0, grid.scrollWidth - grid.clientWidth);
  const isRail = () => !grid.classList.contains('list-layout');
  const isScrollable = () => isRail() && grid.clientWidth > 0 && grid.children.length > 0 && limit() > 2;
  function update() {
    const enabled = isScrollable();
    controls.hidden = !enabled;
    previous.disabled = !enabled || grid.scrollLeft <= 2;
    next.disabled = !enabled || grid.scrollLeft >= limit() - 2;
    grid.setAttribute('tabindex', enabled ? '0' : '-1');
  }
  function requestUpdate() {
    if (frame !== null) return;
    frame = window.requestAnimationFrame(() => { frame = null; update(); });
  }
  function step() {
    const first = grid.firstElementChild;
    const gap = parseFloat(window.getComputedStyle(grid).columnGap) || 0;
    return first ? first.getBoundingClientRect().width + gap : Math.max(220, grid.clientWidth * .8);
  }
  function move(amount) {
    if (!isScrollable()) return;
    const destination = Math.min(limit(), Math.max(0, grid.scrollLeft + amount));
    grid.scrollTo({left:destination, behavior:reduced.matches ? 'auto' : 'smooth'});
    requestUpdate();
  }
  previous.addEventListener('click', () => move(-step()));
  next.addEventListener('click', () => move(step()));
  grid.addEventListener('scroll', requestUpdate, {passive:true});
  grid.addEventListener('keydown', event => {
    if (event.target !== grid || !isScrollable() || event.ctrlKey || event.metaKey || event.altKey) return;
    const amount = event.key === 'ArrowRight' ? step() : event.key === 'ArrowLeft' ? -step() :
      event.key === 'Home' ? -limit() : event.key === 'End' ? limit() :
      event.key === 'PageDown' ? grid.clientWidth : event.key === 'PageUp' ? -grid.clientWidth : null;
    if (amount === null) return;
    event.preventDefault();
    move(amount);
  });
  grid.addEventListener('wheel', event => {
    if (!isScrollable() || event.ctrlKey || event.metaKey || !event.deltaY || Math.abs(event.deltaX) > Math.abs(event.deltaY)) return;
    const pixels = event.deltaY * (event.deltaMode === 1 ? 16 : event.deltaMode === 2 ? grid.clientWidth : 1);
    if ((pixels > 0 && grid.scrollLeft >= limit() - 2) || (pixels < 0 && grid.scrollLeft <= 2)) return;
    event.preventDefault();
    grid.scrollLeft = Math.min(limit(), Math.max(0, grid.scrollLeft + pixels));
    requestUpdate();
  }, {passive:false});
  if (typeof window.ResizeObserver === 'function') new window.ResizeObserver(requestUpdate).observe(grid);
  if (typeof window.MutationObserver === 'function') {
    new window.MutationObserver(records => {
      if (records.some(record => record.type === 'childList')) grid.scrollLeft = 0;
      requestUpdate();
    }).observe(grid, {childList:true,attributes:true,attributeFilter:['class']});
  }
  window.addEventListener('resize', requestUpdate, {passive:true});
  window.addEventListener('pageshow', requestUpdate);
  window.addEventListener('pagehide', () => {
    if (frame !== null) window.cancelAnimationFrame(frame);
    frame = null;
  });
  update();
})();

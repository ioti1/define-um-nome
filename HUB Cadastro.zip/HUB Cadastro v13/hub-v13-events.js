/* Agenda manual do portal. Os eventos usam a mesma publicação JSON/JS do HUB. */
let portalCalendarRenderedDay = '';
let portalCalendarRenderedUpcomingSignature = '';

function portalCalendarDateKey(date){
  return date.getFullYear() + '-' + String(date.getMonth() + 1).padStart(2,'0') + '-' + String(date.getDate()).padStart(2,'0');
}

function portalCalendarDateFromKey(key){
  if(!validEventDate(key)) return null;
  const parts = key.split('-').map(Number);
  return new Date(parts[0],parts[1] - 1,parts[2],12,0,0,0);
}

function portalCalendarSortEvents(events){
  return events.slice().sort((left,right) => left.date.localeCompare(right.date) || (left.time || '').localeCompare(right.time || '') || left.title.localeCompare(right.title,'pt-BR'));
}

function portalCalendarUpcoming(events,today = new Date()){
  const day = portalCalendarDateKey(today);
  const time = String(today.getHours()).padStart(2,'0') + ':' + String(today.getMinutes()).padStart(2,'0');
  return portalCalendarSortEvents(events.filter(event => validEventDate(event.date) && event.title && event.status !== 'cancelled' &&
    (event.date > day || (event.date === day && (!event.time || (event.endTime || event.time) >= time)))));
}

function portalCalendarSettings(){
  const value = typeof portalConfig !== 'undefined' ? portalConfig.calendar : null;
  return normalizeCalendar(value);
}

function portalCalendarEventMarkup(event){
  const date = portalCalendarDateFromKey(event.date);
  if(!date) return '';
  const month = date.toLocaleDateString('pt-BR',{month:'short'}).replace('.','');
  const color = ['teal','blue','gold','purple'].includes(event.color) ? event.color : 'teal';
  const cancelled = event.status === 'cancelled';
  const time = event.time ? event.time + (event.endTime ? '–' + event.endTime : '') : 'Dia inteiro';
  const url = event.url ? safeResourceUrl(event.url) : '';
  const title = url ? '<a class="calendar-event-link" href="' + h(url) + '" target="_blank" rel="noopener noreferrer">' + h(event.title) + '<span aria-hidden="true"> ↗</span></a>' : '<strong class="calendar-event-title">' + h(event.title) + '</strong>';
  return '<article class="calendar-event' + (cancelled ? ' is-cancelled' : '') + '" data-color="' + color + '">' +
    '<time class="calendar-event-date" datetime="' + h(event.date) + '"><span class="calendar-event-day">' + date.getDate() + '</span><span class="calendar-event-month">' + h(month) + '</span></time>' +
    '<div class="calendar-event-copy">' + title + '<div class="calendar-event-meta"><span>' + h(time) + '</span>' +
    (cancelled ? '<span class="calendar-event-cancelled">Cancelado</span>' : '') +
    (event.category ? '<span>' + h(event.category) + '</span>' : '') +
    (event.location ? '<span>' + h(event.location) + '</span>' : '') + '</div>' +
    (event.description ? '<p class="calendar-event-description">' + h(event.description) + '</p>' : '') + '</div></article>';
}

function portalCalendarPublicationLabel(meta){
  if(!meta || typeof meta.updatedAt !== 'string' || !meta.updatedAt.trim()) return 'Última atualização: não informada';
  const stamp = new Date(meta.updatedAt);
  if(!Number.isFinite(stamp.getTime())) return 'Última atualização: não informada';
  const day = stamp.toLocaleDateString('pt-BR',{timeZone:'America/Sao_Paulo',day:'2-digit',month:'2-digit'});
  const time = stamp.toLocaleTimeString('pt-BR',{timeZone:'America/Sao_Paulo',hour:'2-digit',minute:'2-digit',hourCycle:'h23'});
  const author = String(meta.updatedBy || '').trim() || 'responsável não informado';
  return 'Última atualização: ' + day + ', ' + time + ' · ' + author;
}

function renderPortalCalendarUpdate(){
  const node = document.getElementById('calendarState');
  if(node) node.textContent = portalCalendarPublicationLabel(typeof configMeta !== 'undefined' ? configMeta : null);
}

function renderPortalCalendar(){
  const host = document.getElementById('calendarEvents');
  if(!host) return;
  const settings = portalCalendarSettings();
  const today = new Date();
  const dayKey = portalCalendarDateKey(today);
  portalCalendarRenderedDay = dayKey;
  portalCalendarRenderedUpcomingSignature = portalCalendarUpcoming(settings.events,today).map(event => event.id + ':' + event.date + ':' + event.time + ':' + event.endTime).join('|');
  document.getElementById('calendarTitleText').textContent = settings.title || 'Próximos eventos';
  const matching = portalCalendarUpcoming(settings.events,today);
  const limit = settings.maxItems || 6;
  const shown = matching.slice(0,limit);
  renderPortalCalendarUpdate();
  host.innerHTML = shown.length ? shown.map(portalCalendarEventMarkup).join('') : '<div class="calendar-empty panel-empty"><strong>' +
    (settings.events.length ? 'Nenhum evento futuro agendado' : 'Sua agenda começa aqui') + '</strong><p>Os eventos são preenchidos pelo administrador e compartilhados com toda a equipe.</p></div>';
}

function portalCalendarValidationMessage(value){
  if(!value || typeof value !== 'object') return 'Configure o calendário antes de publicar.';
  if(!String(value.title || '').trim()) return 'Informe o título do quadro de eventos.';
  const maxItems = Number(value.maxItems);
  if(!Number.isInteger(maxItems) || maxItems < 1 || maxItems > 12) return 'O limite de eventos visíveis deve ser um número inteiro entre 1 e 12.';
  if(!Array.isArray(value.events)) return 'A lista de eventos não é válida.';
  if(value.events.length > 300) return 'A agenda permite até 300 eventos. Remova eventos antigos antes de adicionar novos.';
  for(const [index,event] of value.events.entries()){
    const prefix = 'Evento nº ' + (index + 1) + ': ';
    if(!event || !String(event.title || '').trim()) return prefix + 'informe o título.';
    if(!validEventDate(event.date)) return prefix + 'informe uma data válida entre 1960 e 2100.';
    if(event.time && !validEventTime(event.time)) return prefix + 'informe um horário inicial válido (HH:mm).';
    if(event.endTime && !validEventTime(event.endTime)) return prefix + 'informe um horário final válido (HH:mm).';
    if(event.endTime && !event.time) return prefix + 'preencha o horário inicial antes do horário final.';
    if(event.time && event.endTime && event.endTime < event.time) return prefix + 'o horário final não pode ser anterior ao inicial. Para eventos de outro dia, crie uma segunda entrada.';
    if(event.url && !safeResourceUrl(event.url)) return prefix + 'informe um link ou caminho válido, ou deixe esse campo vazio.';
    if(!['teal','blue','gold','purple'].includes(event.color)) return prefix + 'selecione uma cor válida.';
    if(!['scheduled','cancelled'].includes(event.status)) return prefix + 'selecione uma situação válida.';
  }
  return '';
}

function validatePortalEvents(){
  return portalCalendarValidationMessage(typeof portalConfig !== 'undefined' ? portalConfig.calendar : null);
}

function renderPortalEventsAdmin(){
  const host = document.getElementById('adminEventItems');
  if(!host) return;
  const value = portalConfig.calendar || normalizeCalendar(null);
  document.getElementById('adminCalendarTitle').value = value.title == null ? 'Próximos eventos' : value.title;
  document.getElementById('adminCalendarMaxItems').value = value.maxItems == null ? 6 : value.maxItems;
  const events = Array.isArray(value.events) ? value.events.slice().sort((a,b) => {
    const av = validEventDate(a.date), bv = validEventDate(b.date);
    if(av !== bv) return av ? -1 : 1;
    return av ? a.date.localeCompare(b.date) || (a.time || '').localeCompare(b.time || '') || (a.title || '').localeCompare(b.title || '','pt-BR') : 0;
  }) : [];
  host.innerHTML = events.length ? events.map((entry,index) => {
    const prefix = 'calendar-event-' + index;
    const field = (name,label,type,extra) => '<div class="form-field event-editor-field-' + name + '"><label for="' + prefix + '-' + name + '">' + label + '</label><input id="' + prefix + '-' + name + '" class="event-field-' + name + '" type="' + type + '" value="' + h(entry[name === 'end-time' ? 'endTime' : name] || '') + '"' + (extra || '') + '></div>';
    const complete = !!(entry.title && validEventDate(entry.date));
    const caption = complete ? entry.date.slice(8,10) + '/' + entry.date.slice(5,7) + (entry.time ? ' · ' + entry.time : '') : 'Preencha o novo evento';
    return '<details class="calendar-admin-row" data-event-id="' + h(entry.id || '') + '"' + (!complete ? ' open' : '') + '><summary class="admin-entry-heading"><span class="admin-event-marker" data-color="' + h(entry.color || 'teal') + '" aria-hidden="true"></span><span class="admin-entry-copy"><strong>' + h(entry.title || 'Novo evento') + '</strong><small>' + h(caption) + (entry.status === 'cancelled' ? ' · Cancelado' : '') + '</small></span><span class="admin-edit-label">Editar / expandir</span></summary><div class="form-grid">' +
      field('title','Título do evento *','text',' maxlength="100" required') +
      field('date','Data *','date',' min="1960-01-01" max="2100-12-31" required') +
      field('time','Horário inicial','time',' step="60"') +
      field('end-time','Horário final','time',' step="60"') +
      '<div class="form-field"><label for="' + prefix + '-color">Marcador</label><select class="event-field-color" id="' + prefix + '-color">' + [['teal','Verde Petros'],['blue','Azul'],['gold','Dourado'],['purple','Violeta']].map(([key,label]) => '<option value="' + key + '"' + ((entry.color || 'teal') === key ? ' selected' : '') + '>' + label + '</option>').join('') + '</select></div>' +
      '<div class="form-field"><label for="' + prefix + '-status">Situação</label><select class="event-field-status" id="' + prefix + '-status"><option value="scheduled"' + (entry.status !== 'cancelled' ? ' selected' : '') + '>Agendado</option><option value="cancelled"' + (entry.status === 'cancelled' ? ' selected' : '') + '>Cancelado</option></select></div></div><details class="admin-more"><summary>Informações complementares</summary><div class="form-grid">' +
      field('category','Categoria','text',' maxlength="80" placeholder="Ex.: Reunião, treinamento, prazo"') +
      field('location','Local ou modalidade','text',' maxlength="180" placeholder="Ex.: Sala de reunião ou Teams"') +
      '<div class="form-field full"><label for="' + prefix + '-description">Descrição</label><textarea class="event-field-description" id="' + prefix + '-description" rows="2" maxlength="1000">' + h(entry.description || '') + '</textarea></div>' +
      '<div class="form-field full"><label for="' + prefix + '-url">Link ou arquivo relacionado (opcional)</label><input class="event-field-url" id="' + prefix + '-url" type="text" value="' + h(entry.url || '') + '" placeholder="https://... ou ./Base de Apoio/..."></div>' +
      '</div></details><div class="portal-row-actions"><button class="admin-action danger" type="button" data-event-action="remove" data-index="' + index + '" aria-label="Remover evento ' + (index + 1) + '">Remover evento</button></div></details>';
  }).join('') : '<div class="admin-list-empty">Nenhum evento cadastrado. Use “Adicionar evento” para preencher sua agenda. O quadro público não exibe exemplos fictícios.</div>';
}

function collectPortalEventsDraft(validate){
  const host = document.getElementById('adminEventItems');
  if(!host) return null;
  const read = (row,name) => (row.querySelector('.event-field-' + name)?.value || '').trim();
  const value = {
    title:document.getElementById('adminCalendarTitle').value.trim(),
    showCalendar:false,
    maxItems:document.getElementById('adminCalendarMaxItems').value.trim(),
    events:[...host.querySelectorAll('.calendar-admin-row')].map((row,index) => ({
      id:row.dataset.eventId || 'event-' + Date.now() + '-' + index,
      title:read(row,'title'),date:read(row,'date'),time:read(row,'time'),endTime:read(row,'end-time'),
      description:read(row,'description'),location:read(row,'location'),url:read(row,'url'),category:read(row,'category'),
      color:read(row,'color') || 'teal',status:read(row,'status') || 'scheduled'
    }))
  };
  /* Não normalizar o rascunho antes de validar: nenhum campo inválido deve desaparecer silenciosamente. */
  portalConfig.calendar = value;
  if(validate){
    const error = portalCalendarValidationMessage(value);
    if(error){
      if(typeof adminMessage !== 'undefined') adminMessage.textContent = error;
      if(typeof toast === 'function') toast(error,'warn');
      return null;
    }
    portalConfig.calendar = normalizeCalendar(value);
  }
  return portalConfig.calendar;
}

function portalCalendarAdminAllowed(){
  return typeof adminModal !== 'undefined' && adminModal.classList.contains('authenticated') && typeof state !== 'undefined' && state.adminMode === 'events';
}

function bindPortalCalendar(){
  const bind = (id,type,handler) => document.getElementById(id)?.addEventListener(type,handler);
  bind('adminAddCalendarEvent','click',() => {
    if(!portalCalendarAdminAllowed()) return;
    if(!collectPortalEventsDraft(false)) return;
    const entries = portalConfig.calendar.events;
    if(entries.length >= 300){ adminMessage.textContent = 'A agenda permite até 300 eventos. Remova eventos antigos para adicionar novos.'; return; }
    entries.push({id:'event-' + Date.now() + '-' + Math.random().toString(36).slice(2,7),title:'',date:'',time:'',endTime:'',description:'',location:'',url:'',category:'',color:'teal',status:'scheduled'});
    saveAppsLocal();
    renderPortalEventsAdmin();
    const rows = document.querySelectorAll('#adminEventItems .calendar-admin-row');
    rows[rows.length - 1]?.querySelector('.event-field-title')?.focus();
    adminMessage.textContent = 'Evento adicionado nesta sessão. Preencha os dados e publique para toda a equipe.';
  });
  bind('adminEventItems','click',event => {
    const button = event.target.closest('[data-event-action]');
    if(!button || !portalCalendarAdminAllowed() || !collectPortalEventsDraft(false)) return;
    const entries = portalConfig.calendar.events;
    const index = Number(button.dataset.index);
    if(!Number.isInteger(index) || index < 0 || index >= entries.length) return;
    if(button.dataset.eventAction === 'remove') entries.splice(index,1);
    else if(['up','down'].includes(button.dataset.eventAction)){
      const target = index + (button.dataset.eventAction === 'up' ? -1 : 1);
      if(target < 0 || target >= entries.length) return;
      [entries[index],entries[target]] = [entries[target],entries[index]];
    }else return;
    saveAppsLocal();
    renderPortalEventsAdmin();
    adminMessage.textContent = 'Agenda alterada nesta sessão. Publique para compartilhar com a equipe.';
  });
  document.addEventListener('visibilitychange',() => { if(!document.hidden) renderPortalCalendar(); });
  /* A data muda à meia-noite e eventos já encerrados saem da lista sem exigir recarga. */
  setInterval(() => {
    if(document.hidden) return;
    const now = new Date();
    const nextDay = portalCalendarDateKey(now);
    const nextSignature = portalCalendarUpcoming(portalCalendarSettings().events,now).map(event => event.id + ':' + event.date + ':' + event.time + ':' + event.endTime).join('|');
    if(nextDay !== portalCalendarRenderedDay || nextSignature !== portalCalendarRenderedUpcomingSignature){
      /* Não substituir um link de evento que está com foco pelo teclado. */
      const host = document.getElementById('calendarEvents');
      if(!host || !host.contains(document.activeElement)) renderPortalCalendar();
    }
  },60000);
}

bindPortalCalendar();

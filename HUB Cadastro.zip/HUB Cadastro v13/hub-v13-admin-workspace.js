/* Organização do editor. Não publica nem cria dependências externas. */
function adminPositionOptions(items,selected){
  return items.map((item,index) => '<option value="' + index + '"' + (index === selected ? ' selected' : '') + '>' + (index + 1) + (index === 0 ? ' · Primeiro' : index === items.length - 1 ? ' · Último' : '') + '</option>').join('');
}
function reorderAdminItems(items,from,to){
  if(!Array.isArray(items) || !Number.isInteger(from) || !Number.isInteger(to) || from < 0 || to < 0 || from >= items.length || to >= items.length || from === to) return false;
  const [item] = items.splice(from,1);
  items.splice(to,0,item);
  return true;
}
function refreshAppPosition(){
  const select = document.getElementById('adminAppPosition');
  if(!select) return;
  select.innerHTML = adminPositionOptions(applications,state.adminIndex);
  document.getElementById('adminAppPrevious').disabled = state.adminIndex <= 0;
  document.getElementById('adminAppNext').disabled = state.adminIndex >= applications.length - 1;
  const search = document.getElementById('adminAppSearch');
  const query = (search?.value || '').trim().toLocaleLowerCase('pt-BR');
  adminAppList.querySelectorAll('[data-admin-index]').forEach(button => { button.hidden = !applications[Number(button.dataset.adminIndex)].name.toLocaleLowerCase('pt-BR').includes(query); });
}
function moveAdminApplication(to){
  if(sharedPublicationBusy || !adminModal.classList.contains('authenticated') || state.adminMode !== 'apps') return;
  if(!collectAdminAppDraft() || !reorderAdminItems(applications,state.adminIndex,to)) return;
  state.adminIndex = to;
  saveAppsLocal();
  renderAdmin();
  render();
  adminMessage.textContent = 'Ordem alterada no rascunho. Publique para compartilhar. Favoritos e ordenação alfabética podem ter prioridade na consulta.';
}
function refreshAdminWorkspace(){
  const names = {apps:'Aplicações',agents:'Agentes de IA',links:'Links úteis',documents:'Documentos rápidos',events:'Calendário e eventos',support:'Central de Apoio',news:'Notícias',data:'Importar e backup'};
  const node = document.getElementById('adminWorkspaceHint');
  if(node) node.textContent = (names[state.adminMode] || 'Administração') + ' · edite o rascunho e publique para compartilhar com toda a equipe.';
  adminModeSwitch.querySelectorAll('[data-admin-mode]').forEach(button => button.setAttribute('aria-current',button.dataset.adminMode === state.adminMode ? 'page' : 'false'));
}
(() => {
  'use strict';
  const bind = (id,type,handler) => document.getElementById(id)?.addEventListener(type,handler);
  bind('adminAppPosition','change',event => moveAdminApplication(Number(event.target.value)));
  bind('adminAppPrevious','click',() => moveAdminApplication(state.adminIndex - 1));
  bind('adminAppNext','click',() => moveAdminApplication(state.adminIndex + 1));
  bind('adminAppSearch','input',event => {
    const query = event.target.value.trim().toLocaleLowerCase('pt-BR');
    adminAppList.querySelectorAll('[data-admin-index]').forEach(button => { button.hidden = !applications[Number(button.dataset.adminIndex)].name.toLocaleLowerCase('pt-BR').includes(query); });
  });
  bind('adminAgents','change',event => {
    if(!event.target.matches('.agent-position') || sharedPublicationBusy || !adminModal.classList.contains('authenticated') || state.adminMode !== 'agents') return;
    const from = Number(event.target.dataset.index), to = Number(event.target.value);
    aiAgents = collectAdminAgents();
    if(!reorderAdminItems(aiAgents,from,to)) return;
    saveAppsLocal(); renderAdminAgents(); renderAgents();
    adminMessage.textContent = 'Posição do agente alterada no rascunho. Publique para compartilhar.';
  });
  adminModeSwitch.querySelectorAll('[data-admin-mode]').forEach(button => {
    const key = {apps:'grid',agents:'bot',links:'link',documents:'document',events:'calendar',support:'folder',news:'document',data:'archive'}[button.dataset.adminMode];
    const glyph = document.createElement('span');
    glyph.className = 'admin-nav-icon'; glyph.setAttribute('aria-hidden','true');
    glyph.innerHTML = icons[key] || icons.document;
    button.prepend(glyph);
  });
  document.getElementById('adminModal')?.addEventListener('input',() => {
    if(sharedPublicationBusy || !adminModal.classList.contains('authenticated')) return;
    adminMessage.textContent = 'Rascunho em edição. Publique quando terminar para disponibilizar à equipe.';
  });
})();

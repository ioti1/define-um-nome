/* Quadros do portal. Configuração vem do mesmo JSON/JS; cache de notícias é separado. */
const PORTAL_NEWS_SOURCES = [
  'https://agenciabrasil.ebc.com.br/tags/previdencia-social',
  'https://agenciabrasil.ebc.com.br/tags/previdencia-complementar',
  'https://agenciabrasil.ebc.com.br/tags/inss',
  'https://agenciabrasil.ebc.com.br/tags/aposentadoria'
];
// API oficial: RSS da InfoMoney não permite leitura pelo HTML local.
// /posts consulta artigos; não agrega as rotas de colunistas/patrocinados.
const PORTAL_INFOMONEY_SOURCE = 'https://www.infomoney.com.br/wp-json/wp/v2/posts?tags=2043,112838,287467,285999&per_page=12&orderby=date&order=desc&_fields=link,title,date,date_gmt';
let portalNewsRequest = 0;
function portalPublicUrl(value){
  try { const url=new URL(value); return url.protocol==='https:' && !url.username && !url.password ? url.href : ''; } catch(error){return '';}
}
function portalNewsSettings(){
  return typeof portalConfig!=='undefined' ? portalConfig.news : {enabled:true,mode:'agencia-brasil',includeInfoMoney:true,sourceLabel:'Agência Brasil',feedUrl:'',keywords:''};
}
function portalNewsCacheKey(settings){
  return 'hubCadastro.news.v13.multi1.' + encodeURIComponent(JSON.stringify([settings.mode,settings.feedUrl,settings.keywords,settings.mode!=='rss'&&settings.includeInfoMoney!==false]));
}
function portalStoredNews(settings){
  try {
    const current=localStorage.getItem(portalNewsCacheKey(settings));
    const oldKey='hubCadastro.news.v12.' + encodeURIComponent(JSON.stringify([settings.mode,settings.feedUrl,settings.keywords]));
    const value=JSON.parse(current||localStorage.getItem(oldKey)||'null');
    if(!value || !Array.isArray(value.items) || !Number.isFinite(Date.parse(value.checkedAt))) return null;
    value.items=value.items.filter(item=>item&&typeof item.title==='string'&&portalPublicUrl(item.url)&&Number.isFinite(Date.parse(item.date))).slice(0,3);
    value.legacy=!current;
    return value.items.length ? value : null;
  }catch(error){return null;}
}
function portalNewsKeywords(value){return String(value||'').split(',').map(x=>x.trim().normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase()).filter(Boolean);}
function portalNewsMatches(title,keywords){
  if(!keywords.length)return true;
  const text=title.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
  return keywords.some(word=>text.includes(word));
}
function parseAgencyNews(markup,source,keywords){
  const doc=new DOMParser().parseFromString(markup,'text/html');
  const rows=[...doc.querySelectorAll('.ultima-noticia')];
  if(!rows.length)throw new Error('O formato da página de notícias mudou.');
  return rows.flatMap(row=>{
    const anchor=row.querySelector('a.titulo-noticia');
    const stamp=row.querySelector('.data-publicacao .data');
    if(!anchor||!stamp)return [];
    const title=(anchor.textContent||'').replace(/\s+/g,' ').trim();
    const url=new URL(anchor.getAttribute('href')||'',source);
    const match=/(\d{2})\/(\d{2})\/(\d{4})\s*-\s*(\d{2}):(\d{2})/.exec(stamp.textContent||'');
    if(url.origin!=='https://agenciabrasil.ebc.com.br'||!url.pathname.includes('/noticia/')||url.pathname.startsWith('/esportes/')||!match||!title||!portalNewsMatches(title,keywords))return [];
    const date=`${match[3]}-${match[2]}-${match[1]}T${match[4]}:${match[5]}:00-03:00`;
    return Number.isFinite(Date.parse(date)) ? [{title,url:url.href,date,source:'Agência Brasil'}] : [];
  });
}
function parsePortalRss(markup,settings){
  const doc=new DOMParser().parseFromString(markup,'application/xml');
  if(doc.querySelector('parsererror'))throw new Error('Feed inválido');
  const keywords=portalNewsKeywords(settings.keywords);
  return [...doc.querySelectorAll('item, entry')].flatMap(row=>{
    const title=(row.querySelector('title')?.textContent||'').replace(/\s+/g,' ').trim();
    const link=row.querySelector('link[rel="alternate"]')||row.querySelector('link:not([rel="self"])')||row.querySelector('link');
    const raw=link?.getAttribute('href')||link?.textContent||'';
    const url=portalPublicUrl(raw.trim());
    const date=row.querySelector('pubDate, published, updated')?.textContent||row.getElementsByTagName('dc:date')[0]?.textContent||'';
    if(!title||!url||!Number.isFinite(Date.parse(date))||!portalNewsMatches(title,keywords))return [];
    return [{title,url,date:new Date(date).toISOString(),source:settings.sourceLabel||'Fonte RSS'}];
  });
}
function parseInfoMoneyNews(markup,keywords){
  const rows=JSON.parse(markup);
  if(!Array.isArray(rows))throw new Error('Resposta inválida da InfoMoney.');
  return rows.slice(0,100).flatMap(row=>{
    if(!row || typeof row.title?.rendered!=='string')return [];
    const resolved=portalPublicUrl(row.link);
    if(!resolved)return [];
    const url=new URL(resolved);
    if(!['www.infomoney.com.br','infomoney.com.br'].includes(url.hostname) || /^\/(?:colunistas|patrocinados|conteudo-patrocinado|tudo-sobre|web-stories|feed)(?:\/|$)/i.test(url.pathname) || url.pathname.split('/').filter(Boolean).length<2)return [];
    const doc=new DOMParser().parseFromString(row.title.rendered,'text/html');
    doc.querySelectorAll('script, style').forEach(node=>node.remove());
    const title=(doc.body?.textContent||'').replace(/\s+/g,' ').trim().slice(0,500);
    const stamp=typeof row.date_gmt==='string' ? row.date_gmt.trim().replace(/Z$/,'') : '';
    if(!title || !portalNewsMatches(title,keywords) || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,3})?$/.test(stamp))return [];
    const date=new Date(stamp+'Z');
    if(!Number.isFinite(date.getTime()) || date.toISOString().slice(0,19)!==stamp.slice(0,19))return [];
    return [{title,url:url.href,date:date.toISOString(),source:'InfoMoney'}];
  });
}
function portalLatestNews(items){
  const seen=new Set();
  return items.filter(item=>{if(seen.has(item.url))return false;seen.add(item.url);return true;})
    .sort((a,b)=>Date.parse(b.date)-Date.parse(a.date)).slice(0,3);
}
function renderPortalNews(items,message){
  document.getElementById('newsStatus').textContent=message;
  document.getElementById('newsItems').innerHTML=items.length ? items.map(item=>{
    const date=Number.isFinite(Date.parse(item.date))?new Date(item.date).toLocaleDateString('pt-BR'):'';
    return '<a class="news-item" href="'+h(portalPublicUrl(item.url))+'" target="_blank" rel="noopener noreferrer"><span class="news-glyph" aria-hidden="true">'+icons.document+'</span><span><small class="news-meta">'+h(item.source||'')+' <time datetime="'+h(item.date)+'">'+h(date)+'</time>'+(item.fromCache===true?' · em cache':'')+'</small><strong>'+h(item.title)+'</strong></span><span class="news-arrow" aria-hidden="true">↗</span></a>';
  }).join('') : '<div class="panel-empty"><strong>Nenhuma notícia carregada</strong><p>O quadro consulta fontes públicas quando há internet. Você também pode abrir a fonte diretamente.</p></div>';
}
async function portalFetchText(url,format='text'){
  const controller=new AbortController();
  const timer=setTimeout(()=>controller.abort(),10000);
  try{
    const response=await fetch(url,{credentials:'omit',referrerPolicy:'no-referrer',signal:controller.signal,cache:'no-store'});
    if(!response.ok)throw new Error('Fonte indisponível');
    const type=response.headers.get('content-type')||'';
    if(format==='json' ? !/^application\/(?:[\w.+-]+\+)?json\b/i.test(type) : !/html|xml|rss|atom|text/i.test(type))throw new Error('Tipo de fonte não suportado');
    const text=await response.text();
    if(text.length>4000000)throw new Error('Fonte excedeu o limite de leitura');
    return text;
  }finally{clearTimeout(timer);}
}
async function updatePortalNews(force=false){
  const request=++portalNewsRequest;
  const refresh=document.getElementById('newsRefresh');refresh.disabled=false;
  const settings=portalNewsSettings();
  const sourceLink=document.getElementById('newsSourceLink');
  sourceLink.href=settings.mode==='rss' ? portalPublicUrl(settings.feedUrl)||'https://agenciabrasil.ebc.com.br' : 'https://agenciabrasil.ebc.com.br/tags/previdencia-social';
  sourceLink.textContent=settings.mode==='rss' ? 'Abrir fonte RSS ↗' : 'Agência Brasil ↗';
  const infoMoneyLink=document.getElementById('newsInfoMoneyLink');
  if(infoMoneyLink)infoMoneyLink.hidden=settings.mode==='rss'||settings.includeInfoMoney===false;
  if(!settings.enabled){renderPortalNews([],'Notícias desativadas pelo administrador.');return;}
  const cached=portalStoredNews(settings);
  const previousFailures=Array.isArray(cached?.failedSources)?cached.failedSources.filter(name=>['Agência Brasil','InfoMoney'].includes(name)).join(' / '):'';
  const cachedPrefix=(cached?.legacy?'Consulta anterior salva · ':'')+(cached?.partial?'Consulta parcial salva · '+(previousFailures?'falha anterior em '+previousFailures+' · ':''):'');
  const cachedDate=cached ? new Date(cached.checkedAt).toLocaleString('pt-BR',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'}) : '';
  if(cached)renderPortalNews(cached.items,cachedPrefix+'Última consulta: '+cachedDate+'. Verificando atualização…');
  else renderPortalNews([],'Consultando fontes públicas…');
  if(!navigator.onLine){renderPortalNews(cached?.items||[],cached?cachedPrefix+'Sem conexão · última consulta: '+cachedDate:'Sem conexão. Notícias serão consultadas ao acessar a internet.');return;}
  if(!force&&cached&&!cached.legacy&&Date.now()-Date.parse(cached.checkedAt)<15*60*1000){renderPortalNews(cached.items,cachedPrefix+'Última consulta: '+cachedDate+' · cache recente. Use ↻ para consultar agora.');return;}
  refresh.disabled=true;
  try{
    let items=[],partial=false,sources=[],failedSources=[];
    if(settings.mode==='rss'){
      const url=portalPublicUrl(settings.feedUrl);
      if(!url)throw new Error('Configure um feed HTTPS válido.');
      items=parsePortalRss(await portalFetchText(url),settings);
      sources=[settings.sourceLabel||'Fonte RSS'];
    }else{
      const keywords=portalNewsKeywords(settings.keywords||'previdencia,aposent,inss,previc,pensao,pensoes,pension,previdenciario,beneficio');
      const providers=PORTAL_NEWS_SOURCES.map(url=>({name:'Agência Brasil',load:async()=>parseAgencyNews(await portalFetchText(url),url,keywords)}));
      if(settings.includeInfoMoney!==false)providers.push({name:'InfoMoney',load:async()=>parseInfoMoneyNews(await portalFetchText(PORTAL_INFOMONEY_SOURCE,'json'),keywords)});
      const results=await Promise.allSettled(providers.map(source=>source.load()));
      const success=results.filter(result=>result.status==='fulfilled');
      if(!success.length)throw new Error('Não foi possível consultar as fontes.');
      partial=success.length<results.length;
      sources=[...new Set(results.flatMap((result,index)=>result.status==='fulfilled'?[providers[index].name]:[]))];
      failedSources=[...new Set(results.flatMap((result,index)=>result.status==='rejected'?[providers[index].name]:[]))];
      items=success.flatMap(result=>result.value);
      // Manter títulos já obtidos da fonte que falhou, sempre identificados como cache.
      if(partial&&cached)items=items.concat(cached.items.filter(item=>failedSources.includes(item.source)&&portalNewsMatches(item.title,keywords)).map(item=>({...item,fromCache:true})));
    }
    if(request!==portalNewsRequest)return;
    items=portalLatestNews(items);
    if(!items.length)throw new Error('A fonte não retornou notícias com os filtros configurados.');
    const checkedAt=new Date().toISOString();
    try{localStorage.setItem(portalNewsCacheKey(settings),JSON.stringify({items,checkedAt,partial,sources,failedSources}));}catch(error){}
    const when=new Date(checkedAt).toLocaleString('pt-BR',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'});
    renderPortalNews(items,(partial?'Consulta parcial · falha em '+failedSources.join(' / ')+' · ':'Última consulta: ')+when+' · '+sources.join(' + '));
  }catch(error){
    if(request!==portalNewsRequest)return;
    renderPortalNews(cached?.items||[],cached?cachedPrefix+'Não foi possível atualizar · última consulta: '+cachedDate:'Não foi possível consultar a fonte. Verifique internet, bloqueio corporativo ou permissão CORS da fonte.');
  }finally{if(request===portalNewsRequest)refresh.disabled=false;}
}
function portalResourceUrl(item){
  if(item.resourceId){const resource=allSupportResources().find(row=>row.id===item.resourceId);if(resource)return safeResourceUrl(resource.path);}
  return safeResourceUrl(item.url||'');
}
function renderPortalResources(hostId,items,kind){
  const host=document.getElementById(hostId);
  const valid=items.map(item=>({...item,resolvedUrl:portalResourceUrl(item)})).filter(item=>item.title&&item.resolvedUrl);
  host.innerHTML=valid.length ? valid.map(item=>'<a class="quick-resource" href="'+h(item.resolvedUrl)+'" target="_blank" rel="noopener noreferrer"><span class="resource-icon" aria-hidden="true">'+(icons[item.icon]||icons[kind==='links'?'link':'document'])+'</span><span><strong>'+h(item.title)+'</strong>'+(item.description?'<small>'+h(item.description)+'</small>':'')+'</span><span class="resource-arrow" aria-hidden="true">↗</span></a>').join('') : '<div class="panel-empty"><strong>'+ (kind==='links'?'Seus atalhos de apoio':'Documentos em destaque')+'</strong><p>Use o Admin para adicionar '+(kind==='links'?'links internos e ferramentas úteis.':'arquivos, manuais ou referências da Central de Apoio.')+'</p></div>';
}
function renderPortalPanels(){
  const value=typeof portalConfig!=='undefined' ? portalConfig : {links:[],documents:[]};
  renderPortalResources('usefulLinks',value.links,'links');
  renderPortalResources('quickDocuments',value.documents,'documents');
  renderPortalCalendar();
  updatePortalNews();
}
function openPortalSection(mode){
  requestPortalAdminSection(mode);
}
document.getElementById('headerMenuToggle').addEventListener('click',()=>{
  const menu=document.getElementById('viewNav');menu.hidden=!menu.hidden;
  document.getElementById('headerMenuToggle').setAttribute('aria-expanded',String(!menu.hidden));
});
document.getElementById('viewNav').addEventListener('click',()=>{document.getElementById('viewNav').hidden=true;document.getElementById('headerMenuToggle').setAttribute('aria-expanded','false');});
document.addEventListener('click',event=>{if(!event.target.closest('#viewNav,#headerMenuToggle')){document.getElementById('viewNav').hidden=true;document.getElementById('headerMenuToggle').setAttribute('aria-expanded','false');}});
document.addEventListener('keydown',event=>{if(event.key==='Escape'){document.getElementById('viewNav').hidden=true;document.getElementById('headerMenuToggle').setAttribute('aria-expanded','false');}});
document.querySelector('.portal-brand').addEventListener('click',event=>{event.preventDefault();setView('home');});
document.getElementById('headerNews').addEventListener('click',()=>{setView('home');document.getElementById('newsPanel').scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth',block:'center'});});
document.getElementById('newsRefresh').addEventListener('click',()=>updatePortalNews(true));
searchInput.addEventListener('keydown',event=>{
  if(event.key==='Enter'){
    event.preventDefault();const query=searchInput.value;
    openPalette();paletteInput.value=query;renderPalette();
  }
});
window.addEventListener('online',()=>updatePortalNews(true));
window.addEventListener('offline',()=>updatePortalNews());
renderPortalPanels();

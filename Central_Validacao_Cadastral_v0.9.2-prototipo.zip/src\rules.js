(function (root, factory) {
  const utils = typeof module === "object" && module.exports ? require("./utils.js") : root.CVCUtils;
  const api = factory(utils);
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.CVCRules = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function (U) {
  "use strict";

  const UFS = ["AC", "AL", "AP", "AM", "BA", "CE", "DF", "ES", "GO", "MA", "MT", "MS", "MG", "PA", "PB", "PR", "PE", "PI", "RJ", "RN", "RS", "RO", "RR", "SC", "SP", "SE", "TO"];
  const IBGE_UF_PREFIX = { 11: "RO", 12: "AC", 13: "AM", 14: "RR", 15: "PA", 16: "AP", 17: "TO", 21: "MA", 22: "PI", 23: "CE", 24: "RN", 25: "PB", 26: "PE", 27: "AL", 28: "SE", 29: "BA", 31: "MG", 32: "ES", 33: "RJ", 35: "SP", 41: "PR", 42: "SC", 43: "RS", 50: "MS", 51: "MT", 52: "GO", 53: "DF" };

  function canonical(value) { return U.normalizeText(value); }
  function normalizeForField(fieldId, value) {
    const raw = U.text(value);
    const upper = canonical(raw);
    if (fieldId === "matricula_petros") return U.normalizeMatricula(raw);
    if (fieldId === "cpf") return U.digits(raw);
    if (fieldId === "nome") return U.normalizeSpaces(raw);
    if (fieldId === "data_nascimento") return U.dateToBR(raw) || U.normalizeSpaces(raw);
    if (["data_obito", "data_invalidez"].includes(fieldId)) return U.dateToISO(raw) || U.normalizeSpaces(raw);
    if (fieldId === "sexo") return ({ MASCULINO: "M", HOMEM: "M", FEMININO: "F", MULHER: "F" })[upper] || upper;
    if (fieldId === "estado_civil") {
      const aliases = { SOLTEIRA: "SOLTEIRO", CASADA: "CASADO", SEPARADA: "SEPARADO", DIVORCIADA: "DIVORCIADO", VIUVA: "VIUVO" };
      return aliases[upper] || upper;
    }
    if (fieldId === "nacionalidade") {
      const common = { BRASIL: "BRA", BRASILEIRA: "BRA", BRASILEIRO: "BRA", ARGENTINA: "ARG", PORTUGAL: "PRT", PORTUGUESA: "PRT", PORTUGUES: "PRT", ITALIA: "ITA", ITALIANA: "ITA", ITALIANO: "ITA", ESPANHA: "ESP", ESPANHOLA: "ESP", ESPANHOL: "ESP", EUA: "USA", "ESTADOS UNIDOS": "USA" };
      return common[upper] || upper.replace(/^([A-Z]{3})\s*[-–—]\s*(.+)$/, "$1 — $2");
    }
    if (["naturalidade_uf", "isencao_ir", "invalidez", "aposentado_inss"].includes(fieldId)) {
      return ({ SIM: "S", NAO: "N", "NÃO": "N", TRUE: "S", FALSE: "N", "1": "S", "0": "N" })[upper] || upper;
    }
    if (fieldId === "naturalidade_municipio") return U.normalizeSpaces(raw).replace(/\s*[-–—]\s*/, " — ");
    if (fieldId === "nif") return raw.trim();
    if (fieldId === "motivo_obito" || fieldId === "tipo_beneficio_inss") return U.normalizeSpaces(raw);
    if (fieldId === "tvp") return raw.trim().replace(",", ".");
    return U.normalizeSpaces(raw);
  }

  function cpfCheckDigits(value) {
    const cpf = U.digits(value);
    if (!/^\d{11}$/.test(cpf) || /^(\d)\1{10}$/.test(cpf)) return false;
    let sum = 0;
    for (let index = 0; index < 9; index += 1) sum += Number(cpf[index]) * (10 - index);
    let digit = 11 - (sum % 11);
    if (digit >= 10) digit = 0;
    if (digit !== Number(cpf[9])) return false;
    sum = 0;
    for (let index = 0; index < 10; index += 1) sum += Number(cpf[index]) * (11 - index);
    digit = 11 - (sum % 11);
    if (digit >= 10) digit = 0;
    return digit === Number(cpf[10]);
  }

  function pass() { return { status: "pass" }; }
  function skip(reason) { return { status: "skip", reason: reason || "Regra não aplicável" }; }
  function fail(message, suggestion) { return { status: "fail", message, suggestion: suggestion || "" }; }
  function compareValue(value, mode) { return mode === "digits" ? U.digits(value) : canonical(value); }

  function evaluate(rule, field, rawValue, values, context) {
    const raw = U.text(rawValue);
    const blank = U.isBlank(raw);
    const normalized = normalizeForField(field.id, raw);
    const params = rule.params || {};

    if (rule.type === "required") return blank ? fail(`${field.label} não está preenchido.`) : pass();
    if (rule.type === "conditionalRequired") {
      const dependency = values[params.field];
      const dependencyText = canonical(dependency);
      const applies = params.nonBlank ? !U.isBlank(dependency) : (params.matches || []).some((item) => dependencyText.startsWith(canonical(item)));
      if (!applies) return skip("Condição não acionada");
      return blank ? fail(`${field.label} é obrigatório para a condição informada em ${context.fieldLabels[params.field] || params.field}.`) : pass();
    }
    if (rule.type === "conditionalBlank") {
      const dependencyText = canonical(values[params.field]);
      const applies = (params.matches || []).includes(dependencyText);
      if (!applies) return skip("Condição não acionada");
      return !blank ? fail(`${field.label} deveria permanecer vazio para a condição informada.`, "Limpar o valor após confirmação") : pass();
    }
    if (blank) return skip("Campo vazio e sem regra de obrigatoriedade acionada");

    switch (rule.type) {
      case "matriculaFormat":
        return raw.length <= 40 && !/[\u0000-\u001F\u007F]/.test(raw) ? pass() : fail("A matrícula contém caractere de controle ou excede 40 caracteres.", normalized);
      case "noWhitespace":
        return /\s/.test(raw) ? fail("A matrícula contém espaços que podem impedir o cruzamento.", normalized) : pass();
      case "cpfFormat":
        return /^\d{11}$/.test(raw.trim()) ? pass() : fail("O CPF deve conter exatamente 11 dígitos, sem máscara.", U.digits(raw));
      case "cpfRepeated":
        return /^(\d)\1{10}$/.test(U.digits(raw)) ? fail("CPF formado por um único dígito repetido.") : pass();
      case "cpfCheckDigits":
        return cpfCheckDigits(raw) ? pass() : fail("Dígitos verificadores do CPF são inválidos.", U.digits(raw));
      case "unique": {
        const key = context.uniqueKey(field.id, raw);
        const count = context.uniqueCounts[field.id]?.get(key) || 0;
        return key && count > 1 ? fail(`${field.label} aparece ${count} vezes no arquivo.`) : pass();
      }
      case "lengthBetween":
        return raw.trim().length >= params.min && raw.trim().length <= params.max ? pass() : fail(`${field.label} deve ter entre ${params.min} e ${params.max} caracteres.`, normalized);
      case "maxLength":
        return raw.length <= params.max ? pass() : fail(`${field.label} excede ${params.max} caracteres.`, raw.slice(0, params.max));
      case "exactLength":
        return raw.trim().length === params.length ? pass() : fail(`${field.label} deve ter exatamente ${params.length} caracteres.`, normalized);
      case "nameCharacters": {
        let valid;
        try { valid = /^[\p{L}\p{M}]+(?:[ '\-][\p{L}\p{M}]+)*$/u.test(raw.trim()); }
        catch (_) { valid = /^[A-Za-zÀ-ÖØ-öø-ÿ]+(?:[ '\-][A-Za-zÀ-ÖØ-öø-ÿ]+)*$/.test(raw.trim()); }
        return valid ? pass() : fail("O nome contém números ou caracteres incompatíveis com nome civil.", normalized);
      }
      case "noControl":
        return /[\u0000-\u001F\u007F]/.test(raw) ? fail("O valor contém caractere de controle invisível.", normalized) : pass();
      case "noDoubleSpaces":
        return /\s{2,}/.test(raw) ? fail("O nome contém espaços consecutivos.", normalized) : pass();
      case "noTitles":
        return /^(SR\.?|SRA\.?|DR\.?|DRA\.?|PROF\.?|PROFA\.?)\s+/i.test(raw.trim()) ? fail("O nome começa com título ou tratamento indevido.", raw.trim().replace(/^(SR\.?|SRA\.?|DR\.?|DRA\.?|PROF\.?|PROFA\.?)\s+/i, "")) : pass();
      case "validDate":
        return U.parseDate(raw) ? pass() : fail("Data inexistente ou em formato não reconhecido.");
      case "brazilianDate": {
        const value = raw.trim();
        const date = U.parseDate(value);
        if (!date) return fail("Data inexistente ou inválida. Use o padrão DD/MM/AAAA.");
        const excelSerial = /^\d+(?:[.,]\d+)?$/.test(value) && Number(value.replace(",", ".")) > 20000;
        return /^\d{2}\/\d{2}\/\d{4}$/.test(value) || excelSerial
          ? pass()
          : fail("Use o padrão brasileiro DD/MM/AAAA.", U.dateToBR(date));
      }
      case "notFuture": {
        const date = U.parseDate(raw);
        if (!date) return skip("Data inválida avaliada por outra regra");
        const today = new Date();
        const limit = new Date(Date.UTC(today.getUTCFullYear(), today.getUTCMonth(), today.getUTCDate()));
        const suggestion = field.id === "data_nascimento" ? U.dateToBR(date) : U.dateToISO(date);
        return date <= limit ? pass() : fail("A data está no futuro.", suggestion);
      }
      case "ageRange": {
        const age = U.ageAt(raw);
        if (age == null) return skip("Data inválida avaliada por outra regra");
        return age >= params.min && age <= params.max ? pass() : fail(`Idade calculada de ${age} anos está fora do intervalo ${params.min}–${params.max}.`);
      }
      case "dateBeforeField": {
        const current = U.parseDate(raw), other = U.parseDate(values[params.field]);
        if (!current || !other) return skip("Uma das datas necessárias não está preenchida ou é inválida");
        return current <= other ? pass() : fail(`${field.label} é posterior a ${context.fieldLabels[params.field] || params.field}.`);
      }
      case "dateAfterField": {
        const current = U.parseDate(raw), other = U.parseDate(values[params.field]);
        if (!current || !other) return skip("Uma das datas necessárias não está preenchida ou é inválida");
        return current >= other ? pass() : fail(`${field.label} é anterior a ${context.fieldLabels[params.field] || params.field}.`);
      }
      case "enum": {
        const value = canonical(raw);
        const allowed = (params.values || []).map(canonical);
        if (allowed.includes(value)) return pass();
        const alias = Object.entries(params.aliases || {}).find(([key]) => canonical(key) === value)?.[1];
        return fail(`Valor fora do domínio permitido: ${params.values.join(", ")}.`, alias || normalized);
      }
      case "iso3":
        return /^[A-Z]{3}(?:\s*[-–—]\s*.+)?$/.test(raw.trim().toUpperCase()) ? pass() : fail("Use código de país com três letras (ex.: BRA ou BRA — Brasil).", normalized);
      case "uf":
        return UFS.includes(raw.trim().toUpperCase()) ? pass() : fail("Sigla de UF inexistente no domínio oficial.", raw.trim().toUpperCase());
      case "ibgeFormat":
        return /^\d{7}(?:\s*[-–—]\s*.+)?$/.test(raw.trim()) ? pass() : fail("Informe código IBGE com 7 dígitos, opcionalmente seguido do nome.", normalized);
      case "ibgeWithName":
        return /^\d{7}\s*[-–—]\s*.+$/.test(raw.trim()) ? pass() : fail("O código IBGE está sem o nome do município.");
      case "municipioUf": {
        const match = raw.trim().match(/^(\d{2})\d{5}/);
        const uf = canonical(values[params.field]);
        if (!match || !uf) return skip("Código IBGE ou UF indisponível");
        const expected = IBGE_UF_PREFIX[match[1]];
        return expected && expected === uf ? pass() : fail(`O prefixo IBGE ${match[1]} corresponde a ${expected || "UF desconhecida"}, não a ${uf}.`);
      }
      case "nifFormat":
        return /^[A-Za-z0-9][A-Za-z0-9._\/-]{0,39}$/.test(raw) ? pass() : fail("NIF deve ter até 40 caracteres alfanuméricos e separadores . / _ -.", raw.trim());
      case "noOuterSpaces":
        return raw === raw.trim() ? pass() : fail("O valor contém espaços externos.", raw.trim());
      case "differentFromField": {
        const left = compareValue(raw, params.compare), right = compareValue(values[params.field], params.compare);
        if (!right) return skip("Campo de comparação vazio");
        return left !== right ? pass() : fail(`${field.label} é igual a ${context.fieldLabels[params.field] || params.field}. Confirme se a reutilização é legítima.`);
      }
      case "cidFormat": {
        const value = canonical(raw);
        return /^[A-Z][0-9]{2}(?:\.[0-9A-Z]{1,2})?(?:\s*[-–—]\s*.+)?$/.test(value) || value === "NAO INFORMADO" ? pass() : fail("Valor não segue formato compatível com CID (ex.: I21.0 — descrição).", normalized);
      }
      case "benefitFormat": {
        const value = canonical(raw);
        const known = /(APOSENTADORIA|PENSAO POR MORTE|AUXILIO|INCAPACIDADE)/.test(value);
        return /^\d{2,3}\s*[-–—]\s*.+$/.test(raw.trim()) || known ? pass() : fail("Informe código/espécie com descrição controlada.", normalized);
      }
      case "containsWhen": {
        const dependency = canonical(values[params.field]);
        const applies = (params.matches || []).map(canonical).includes(dependency);
        if (!applies) return skip("Condição não acionada");
        return new RegExp(params.contains, "i").test(canonical(raw)) ? pass() : fail(`${field.label} parece incompatível com ${context.fieldLabels[params.field] || params.field}.`);
      }
      case "integer": {
        const value = Number(raw.replace(",", "."));
        return Number.isInteger(value) ? pass() : fail("O valor deve ser um número inteiro de meses.", Number.isFinite(value) ? String(Math.round(value)) : "");
      }
      case "minNumber": {
        const value = Number(raw.replace(",", "."));
        if (!Number.isFinite(value)) return skip("Valor não numérico avaliado por outra regra");
        return value >= params.min ? pass() : fail(`O valor deve ser maior ou igual a ${params.min}.`);
      }
      case "maxNumber": {
        const value = Number(raw.replace(",", "."));
        if (!Number.isFinite(value)) return skip("Valor não numérico avaliado por outra regra");
        return value <= params.max ? pass() : fail(`O valor excede o limite operacional de ${params.max}.`);
      }
      default:
        return skip("Tipo de regra ainda não implementado");
    }
  }

  function uniqueKey(fieldId, value) {
    if (fieldId === "cpf") return U.digits(value);
    if (fieldId === "matricula_petros") return U.normalizeMatricula(value).toUpperCase();
    return canonical(value);
  }

  return { UFS, IBGE_UF_PREFIX, canonical, normalizeForField, cpfCheckDigits, uniqueKey, evaluate };
});

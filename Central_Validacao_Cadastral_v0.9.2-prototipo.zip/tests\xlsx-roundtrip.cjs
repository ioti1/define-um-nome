const assert = require("node:assert/strict");
global.JSZip = require("../vendor/jszip.min.js");
const Xlsx = require("../src/xlsx.js");

(async () => {
  const source = {
    Tratamento: [
      ["Matrícula Petros", "VALIDAÇÃO · Matrícula Petros", "ACHADOS · Matrícula Petros", "CPF", "VALIDAÇÃO · CPF", "ACHADOS · CPF", "RESULTADO GERAL"],
      ["000001", "Consistente", "", "52998224725", "Consistente", "", "Consistente"],
      ["000002", "Consistente", "", "11144477735", "Aprovado com ressalvas", "Revisar documento", "Aprovado com ressalvas"]
    ],
    Resumo: [{ Indicador: "Registros", Valor: 2 }]
  };
  const blob = await Xlsx.write(source);
  assert.ok(blob.size > 1000, "arquivo XLSX deve conter estrutura compactada");
  const zip = await global.JSZip.loadAsync(await blob.arrayBuffer());
  const treatmentXml = await zip.file("xl/worksheets/sheet1.xml").async("string");
  const stylesXml = await zip.file("xl/styles.xml").async("string");
  assert.match(treatmentXml, /s="3"/, "cabeçalho de validação deve usar estilo próprio");
  assert.match(treatmentXml, /s="4"/, "dados de validação devem usar preenchimento próprio");
  assert.match(treatmentXml, /s="5"/, "cabeçalho de controle deve usar estilo próprio");
  assert.match(treatmentXml, /s="6"/, "dados de controle devem usar preenchimento próprio");
  assert.match(stylesXml, /FF17847B/);
  assert.match(stylesXml, /FFFFF2DF/);
  const file = { name: "roundtrip.xlsx", arrayBuffer: () => blob.arrayBuffer() };
  const sheets = await Xlsx.read(file);
  assert.deepEqual(Object.keys(sheets), ["Tratamento", "Resumo"]);
  assert.equal(sheets.Tratamento[1][0], "000001", "zeros à esquerda devem ser preservados");
  assert.equal(sheets.Tratamento[2][6], "Aprovado com ressalvas");
  assert.equal(sheets.Resumo[1][1], "2");
  console.log("✓ Escrita e releitura XLSX aprovadas, incluindo múltiplas abas e zeros à esquerda.");
})().catch((error) => { console.error(error); process.exit(1); });

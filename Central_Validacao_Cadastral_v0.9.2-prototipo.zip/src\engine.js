(function (root, factory) {
  const U = typeof module === "object" && module.exports ? require("./utils.js") : root.CVCUtils;
  const Catalog = typeof module === "object" && module.exports ? require("./catalog.js") : root.CVCCatalog;
  const Rules = typeof module === "object" && module.exports ? require("./rules.js") : root.CVCRules;
  const Config = typeof module === "object" && module.exports ? require("./config.js") : root.CVCConfig;
  const api = factory(U, Catalog, Rules, Config);
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.CVCEngine = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function (U, Catalog, Rules, Config) {
  "use strict";

  function autoMap(headers) {
    const normalized = headers.map(U.normalizeHeader);
    const mapping = {};
    const used = new Set();
    Catalog.fields.forEach((field) => {
      const aliases = field.aliases.map(U.normalizeHeader);
      let index = normalized.findIndex((header, column) => !used.has(column) && aliases.includes(header));
      if (index < 0) {
        index = normalized.findIndex((header, column) => !used.has(column) && aliases.some((alias) => alias.length >= 5 && (header.includes(alias) || alias.includes(header))));
      }
      if (index >= 0) { mapping[field.id] = index; used.add(index); }
    });
    return mapping;
  }

  function selectedRulesFor(field, selection) {
    const selected = new Set(selection?.[field.id] || []);
    return field.rules.filter((rule) => selected.has(rule.id));
  }

  function mappedValues(row, mapping) {
    const values = {};
    Object.entries(mapping || {}).forEach(([fieldId, column]) => {
      if (column !== "" && column != null && Number(column) >= 0) values[fieldId] = row[Number(column)] ?? "";
    });
    return values;
  }

  function buildUniqueCounts(records, mapping, selection) {
    const counts = {};
    Catalog.fields.forEach((field) => {
      if (mapping[field.id] == null || !selectedRulesFor(field, selection).some((item) => item.type === "unique")) return;
      const map = new Map();
      records.forEach((record) => {
        const raw = record.row[Number(mapping[field.id])] ?? "";
        const key = Rules.uniqueKey(field.id, raw);
        if (key) map.set(key, (map.get(key) || 0) + 1);
      });
      counts[field.id] = map;
    });
    return counts;
  }

  function initFieldStats(mapping, selection) {
    const stats = {};
    Catalog.fields.forEach((field) => {
      if (mapping[field.id] == null) return;
      const rules = selectedRulesFor(field, selection);
      stats[field.id] = { fieldId: field.id, label: field.label, group: field.group, rules: rules.length, evaluations: 0, passes: 0, failures: 0, errors: 0, warnings: 0, skipped: 0, affected: new Set() };
    });
    return stats;
  }

  function finalizeFieldStats(stats, total) {
    return Object.values(stats).map((item) => ({
      fieldId: item.fieldId, label: item.label, group: item.group, rules: item.rules,
      evaluations: item.evaluations, passes: item.passes, failures: item.failures,
      errors: item.errors, warnings: item.warnings, skipped: item.skipped,
      affectedRecords: item.affected.size,
      conformity: item.evaluations ? item.passes / item.evaluations : 1,
      recordConformity: total ? (total - item.affected.size) / total : 1
    })).sort((a, b) => a.recordConformity - b.recordConformity || b.failures - a.failures);
  }

  async function process(options) {
    const startedAt = globalThis.performance?.now ? globalThis.performance.now() : Date.now();
    const mapping = options.mapping || {};
    const selection = options.selection || {};
    const firstDataRow = Number(options.firstDataRow || 2);
    const sourceRows = options.rows || [];
    const records = sourceRows.map((row, index) => ({ row, rowNumber: firstDataRow + index })).filter((item) => item.row.some((value) => !U.isBlank(value)));
    const uniqueCounts = buildUniqueCounts(records, mapping, selection);
    const fieldLabels = Object.fromEntries(Catalog.fields.map((field) => [field.id, field.label]));
    const fieldStats = initFieldStats(mapping, selection);
    const ruleStats = {};
    const output = [];
    let totalIssues = 0, errorCount = 0, warningCount = 0, skippedCount = 0;
    const context = { uniqueCounts, uniqueKey: Rules.uniqueKey, fieldLabels };

    for (let index = 0; index < records.length; index += 1) {
      const source = records[index];
      const values = mappedValues(source.row, mapping);
      const issues = [];
      const normalized = {};
      const fieldResults = {};
      Catalog.fields.forEach((field) => {
        if (mapping[field.id] == null) return;
        const raw = values[field.id] ?? "";
        normalized[field.id] = Rules.normalizeForField(field.id, raw);
        const activeRules = selectedRulesFor(field, selection);
        if (!activeRules.length) return;
        let fieldEvaluations = 0, fieldErrors = 0, fieldWarnings = 0;
        activeRules.forEach((rule) => {
          const statKey = `${field.id}.${rule.id}`;
          if (!ruleStats[statKey]) ruleStats[statKey] = { key: statKey, fieldId: field.id, field: field.label, ruleId: rule.id, rule: rule.label, severity: rule.severity, evaluations: 0, passes: 0, failures: 0, skipped: 0 };
          const stats = fieldStats[field.id];
          const missingDependency = (rule.requires || []).find((required) => mapping[required] == null);
          const result = missingDependency ? { status: "skip", reason: `Dependência ${fieldLabels[missingDependency] || missingDependency} não mapeada` } : Rules.evaluate(rule, field, raw, values, context);
          if (result.status === "skip") {
            skippedCount += 1; stats.skipped += 1; ruleStats[statKey].skipped += 1; return;
          }
          stats.evaluations += 1; ruleStats[statKey].evaluations += 1; fieldEvaluations += 1;
          if (result.status === "pass") { stats.passes += 1; ruleStats[statKey].passes += 1; return; }
          stats.failures += 1; ruleStats[statKey].failures += 1; stats.affected.add(source.rowNumber);
          if (rule.severity === "error") { stats.errors += 1; errorCount += 1; fieldErrors += 1; }
          else { stats.warnings += 1; warningCount += 1; fieldWarnings += 1; }
          totalIssues += 1;
          issues.push({
            rowNumber: source.rowNumber, fieldId: field.id, field: field.label, group: field.group,
            ruleId: rule.id, rule: rule.label, severity: rule.severity, weight: rule.weight,
            value: U.text(raw), normalized: normalized[field.id], message: result.message || rule.description,
            suggestion: result.suggestion || (normalized[field.id] !== U.text(raw) ? normalized[field.id] : "")
          });
        });
        fieldResults[field.id] = fieldErrors ? Config.STATUS.FAIL : fieldWarnings ? Config.STATUS.WARNING : fieldEvaluations ? Config.STATUS.PASS : "Não avaliado";
      });
      const errors = issues.filter((item) => item.severity === "error").length;
      const warnings = issues.length - errors;
      const status = errors ? Config.STATUS.FAIL : warnings ? Config.STATUS.WARNING : Config.STATUS.PASS;
      output.push({
        index, rowNumber: source.rowNumber, source: source.row, values, normalized, fieldResults, issues,
        errors, warnings, status, matricula: U.text(values[Config.MASTER_FIELD] || "")
      });
      if ((index + 1) % (options.chunkSize || Config.PROCESS_CHUNK) === 0) {
        options.onProgress?.({ current: index + 1, total: records.length, percent: 100 * (index + 1) / Math.max(records.length, 1), phase: "Aplicando regras de consistência" });
        await U.yieldToMain();
      }
    }
    options.onProgress?.({ current: records.length, total: records.length, percent: 100, phase: "Consolidação concluída" });
    const invalid = output.filter((item) => item.status === Config.STATUS.FAIL).length;
    const withWarnings = output.filter((item) => item.status === Config.STATUS.WARNING).length;
    const consistent = output.length - invalid - withWarnings;
    const mappedFields = Catalog.fields.filter((field) => mapping[field.id] != null).length;
    const selectedRuleCount = Catalog.selectedRuleCount(selection);
    const finishedAt = globalThis.performance?.now ? globalThis.performance.now() : Date.now();
    return {
      records: output,
      issues: output.flatMap((item) => item.issues),
      fieldStats: finalizeFieldStats(fieldStats, output.length),
      ruleStats: Object.values(ruleStats).sort((a, b) => b.failures - a.failures || a.rule.localeCompare(b.rule)),
      summary: {
        total: output.length, consistent, withWarnings, invalid,
        approved: consistent + withWarnings,
        passRate: output.length ? (consistent + withWarnings) / output.length : 0,
        cleanRate: output.length ? consistent / output.length : 0,
        issueCount: totalIssues, errorCount, warningCount, skippedCount,
        mappedFields, selectedRules: selectedRuleCount,
        durationMs: Math.max(0, finishedAt - startedAt)
      }
    };
  }

  return { autoMap, selectedRulesFor, mappedValues, buildUniqueCounts, process };
});

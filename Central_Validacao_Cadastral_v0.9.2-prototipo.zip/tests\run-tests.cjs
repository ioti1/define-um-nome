const assert = require("node:assert/strict");
const U = require("../src/utils.js");
const Catalog = require("../src/catalog.js");
const Rules = require("../src/rules.js");
const Engine = require("../src/engine.js");
const IO = require("../src/io.js");
const Config = require("../src/config.js");
const Exports = require("../src/exports.js");

const tests = [];
function test(name, fn) { tests.push({ name, fn }); }
function rule(fieldId, ruleId) { return Catalog.getField(fieldId).rules.find((item) => item.id === ruleId); }
function evaluate(fieldId, ruleId, value, values, extra) {
  const field = Catalog.getField(fieldId);
  return Rules.evaluate(rule(fieldId, ruleId), field, value, values || { [fieldId]: value }, Object.assign({
    uniqueCounts: {}, uniqueKey: Rules.uniqueKey,
    fieldLabels: Object.fromEntries(Catalog.fields.map((item) => [item.id, item.label]))
  }, extra || {}));
}

test("catálogo expõe 17 campos oficiais e a chave mestre", () => {
  assert.equal(Catalog.fields.length, 18);
  assert.equal(Catalog.fields.filter((field) => field.catalog).length, 17);
  assert.equal(Catalog.getField("matricula_petros").catalog, false);
});
test("catálogo possui regras locais em todos os campos", () => {
  assert.ok(Catalog.fields.every((field) => field.rules.length));
  assert.ok(Catalog.fields.flatMap((field) => field.rules).length >= 53);
});
test("tabela de resultados usa 20 registros por página por padrão", () => assert.equal(Config.TABLE_PAGE_SIZE, 20));
test("paginação navega 50 mil linhas em blocos de 20 ou 100 e oferece modo Todos", () => {
  assert.deepEqual(U.paginationModel(50000, 1, 20, 20), { total: 50000, showAll: false, pageSize: 20, pageCount: 2500, page: 1, start: 0, end: 20 });
  assert.deepEqual(U.paginationModel(50000, 501, 100, 20), { total: 50000, showAll: false, pageSize: 100, pageCount: 500, page: 500, start: 49900, end: 50000 });
  assert.deepEqual(U.paginationModel(50000, 250, "all", 20), { total: 50000, showAll: true, pageSize: 50000, pageCount: 1, page: 1, start: 0, end: 50000 });
  assert.deepEqual(U.pageTokens(25, 100), [1, "…", 23, 24, 25, 26, 27, "…", 100]);
});
test("normaliza cabeçalhos ignorando acento, caixa e espaços", () => assert.equal(U.normalizeHeader("  Matrícula   Petros "), "MATRICULA PETROS"));
test("preserva zeros de matrícula e remove espaços", () => assert.equal(U.normalizeMatricula(" 00 0123 "), "000123"));
test("interpreta datas brasileira, ISO e serial Excel", () => {
  assert.equal(U.dateToISO("03/07/2026"), "2026-07-03");
  assert.equal(U.dateToISO("2026-07-03"), "2026-07-03");
  assert.equal(U.dateToISO("45444"), "2024-06-01");
  assert.equal(U.dateToBR("2026-07-03"), "03/07/2026");
});
test("rejeita data inexistente e ano isolado", () => {
  assert.equal(U.parseDate("31/02/2026"), null);
  assert.equal(U.parseDate("2026"), null);
});
test("valida CPF conhecido pelo módulo 11", () => assert.equal(Rules.cpfCheckDigits("52998224725"), true));
test("rejeita CPF com dígito incorreto e sequência repetida", () => {
  assert.equal(Rules.cpfCheckDigits("52998224724"), false);
  assert.equal(Rules.cpfCheckDigits("11111111111"), false);
  assert.equal(evaluate("cpf", "repeated", "11111111111").status, "fail");
});
test("formato de CPF exige valor mestre sem máscara", () => {
  const result = evaluate("cpf", "format", "529.982.247-25");
  assert.equal(result.status, "fail");
  assert.equal(result.suggestion, "52998224725");
});
test("domínio M/F sugere normalização sem aprovar texto livre", () => {
  const result = evaluate("sexo", "domain", "Masculino");
  assert.equal(result.status, "fail");
  assert.equal(result.suggestion, "M");
});
test("nome aceita acentos, hífen e apóstrofo", () => {
  assert.equal(evaluate("nome", "characters", "Ana Cláudia D'Ávila-Souza").status, "pass");
  assert.equal(evaluate("nome", "characters", "Ana 2").status, "fail");
});
test("data de nascimento exige DD/MM/AAAA e sugere conversão", () => {
  assert.equal(evaluate("data_nascimento", "valid", "20/05/1980").status, "pass");
  const iso = evaluate("data_nascimento", "valid", "1980-05-20");
  assert.equal(iso.status, "fail");
  assert.equal(iso.suggestion, "20/05/1980");
  assert.equal(evaluate("data_nascimento", "valid", "45444").status, "pass", "serial nativo do Excel deve ser reconhecido");
  assert.equal(Rules.normalizeForField("data_nascimento", "1980-05-20"), "20/05/1980");
});
test("data futura é reprovada com sugestão brasileira", () => {
  const result = evaluate("data_nascimento", "future", "01/01/2099");
  assert.equal(result.status, "fail");
  assert.equal(result.suggestion, "01/01/2099");
});
test("UF valida domínio oficial", () => {
  assert.equal(evaluate("naturalidade_uf", "domain", "SP").status, "pass");
  assert.equal(evaluate("naturalidade_uf", "domain", "XX").status, "fail");
});
test("consistência município/UF usa prefixo do IBGE", () => {
  assert.equal(evaluate("naturalidade_municipio", "uf_consistency", "3550308 — São Paulo", { naturalidade_municipio: "3550308 — São Paulo", naturalidade_uf: "SP" }).status, "pass");
  assert.equal(evaluate("naturalidade_municipio", "uf_consistency", "3304557 — Rio de Janeiro", { naturalidade_municipio: "3304557 — Rio de Janeiro", naturalidade_uf: "SP" }).status, "fail");
});
test("data de invalidez é obrigatória quando indicador é S", () => {
  assert.equal(evaluate("data_invalidez", "required_if_invalid", "", { data_invalidez: "", invalidez: "S" }).status, "fail");
  assert.equal(evaluate("data_invalidez", "required_if_invalid", "2024-01-02", { data_invalidez: "2024-01-02", invalidez: "S" }).status, "pass");
  assert.equal(evaluate("data_invalidez", "required_if_invalid", "", { data_invalidez: "", invalidez: "N" }).status, "skip");
});
test("TVP deve ser inteiro e não negativo", () => {
  assert.equal(evaluate("tvp", "integer", "146").status, "pass");
  assert.equal(evaluate("tvp", "integer", "14,5").status, "fail");
  assert.equal(evaluate("tvp", "non_negative", "-1").status, "fail");
});
test("detecção de delimitador e parser preservam aspas e quebras", () => {
  const content = 'Matrícula;Nome;Observação\r\n0001;"Ana; Maria";"Linha 1\nLinha 2"\r\n';
  assert.equal(IO.detectDelimiter(content), ";");
  const rows = IO.parseDelimited(content, ";");
  assert.deepEqual(rows[1], ["0001", "Ana; Maria", "Linha 1\nLinha 2"]);
});
test("mapeamento automático reconhece aliases do catálogo", () => {
  const mapping = Engine.autoMap(["Matrícula", "NR_CPF", "Data Nascimento", "FL_INVALIDEZ"]);
  assert.deepEqual(mapping, { matricula_petros: 0, cpf: 1, data_nascimento: 2, invalidez: 3 });
});
test("processamento integrado separa registro consistente de inconsistente", async () => {
  const headers = ["Matrícula Petros", "CPF", "Nome", "Data de Nascimento", "Sexo", "Nacionalidade", "Naturalidade UF", "Naturalidade Município", "Invalidez", "Data da Invalidez", "Aposentado INSS", "Tipo de Benefício INSS", "TVP"];
  const rows = [
    ["0001", "52998224725", "Ana Maria", "20/05/1980", "F", "BRA — Brasil", "SP", "3550308 — São Paulo", "N", "", "N", "", "146"],
    ["0002", "11111111111", "Dr. Carlos  Silva", "01/01/2099", "Masculino", "Brasil", "XX", "3304557 — Rio de Janeiro", "S", "", "S", "21 — Pensão por morte", "-3"]
  ];
  const mapping = Engine.autoMap(headers);
  const active = Object.fromEntries(Catalog.fields.filter((field) => mapping[field.id] != null).map((field) => [field.id, Catalog.defaultRuleSelection()[field.id]]));
  const result = await Engine.process({ rows, mapping, selection: active, firstDataRow: 2, chunkSize: 1 });
  assert.equal(result.summary.total, 2);
  assert.equal(result.records[0].status, Config.STATUS.PASS);
  assert.equal(result.records[1].status, Config.STATUS.FAIL);
  assert.equal(result.records[0].rowNumber, 2);
  assert.ok(result.records[1].errors >= 8);
  assert.ok(result.records[1].warnings >= 2);
  assert.equal(result.summary.passRate, 0.5);
  assert.equal(result.records[0].fieldResults.cpf, Config.STATUS.PASS);
  assert.equal(result.records[1].fieldResults.cpf, Config.STATUS.FAIL);
});
test("Excel de tratamento intercala validação por campo sem deslocar colunas vazias", () => {
  const state = {
    headers: ["Matrícula Petros", "CPF", "Nome"],
    mapping: { matricula_petros: 0, cpf: 1, nome: 2 },
    selection: { matricula_petros: ["required"], cpf: ["check_digits"], nome: ["required"] }
  };
  const records = [{
    source: ["000001", "11111111111"], status: Config.STATUS.FAIL, errors: 1, warnings: 0,
    fieldResults: { matricula_petros: Config.STATUS.PASS, cpf: Config.STATUS.FAIL, nome: Config.STATUS.FAIL },
    issues: [
      { fieldId: "cpf", field: "CPF", severity: "error", rule: "Dígitos verificadores válidos", message: "CPF inválido.", suggestion: "" },
      { fieldId: "nome", field: "Nome", severity: "error", rule: "Nome preenchido", message: "Nome vazio.", suggestion: "" }
    ]
  }];
  const [headers, row] = Exports.treatmentRows(state, records);
  assert.equal(row[headers.indexOf("Matrícula Petros")], "000001");
  assert.equal(row[headers.indexOf("CPF")], "11111111111");
  assert.equal(row[headers.indexOf("Nome")], "", "coluna original vazia deve permanecer vazia");
  assert.equal(row[headers.indexOf("VALIDAÇÃO · CPF")], Config.STATUS.FAIL);
  assert.equal(row[headers.indexOf("VALIDAÇÃO · Nome")], Config.STATUS.FAIL);
  assert.ok(headers.indexOf("VALIDAÇÃO · CPF") > headers.indexOf("CPF"));
  assert.ok(headers.indexOf("VALIDAÇÃO · CPF") < headers.indexOf("Nome"));
});
test("duplicidade afeta todas as ocorrências da chave", async () => {
  const result = await Engine.process({
    rows: [["0001"], ["0001"]], mapping: { matricula_petros: 0 },
    selection: { matricula_petros: ["unique"] }, firstDataRow: 2
  });
  assert.equal(result.summary.invalid, 2);
  assert.ok(result.records.every((record) => record.issues[0].message.includes("2 vezes")));
});
test("regra com dependência ausente fica não avaliada, sem falso erro", async () => {
  const result = await Engine.process({
    rows: [["2024-01-01"]], mapping: { data_invalidez: 0 },
    selection: { data_invalidez: ["required_if_invalid"] }, firstDataRow: 2
  });
  assert.equal(result.summary.invalid, 0);
  assert.equal(result.summary.skippedCount, 1);
});
test("linhas totalmente vazias são ignoradas mantendo numeração de origem", async () => {
  const result = await Engine.process({
    rows: [["0001"], [""], ["0003"]], mapping: { matricula_petros: 0 },
    selection: { matricula_petros: ["required"] }, firstDataRow: 5
  });
  assert.deepEqual(result.records.map((record) => record.rowNumber), [5, 7]);
});

(async () => {
  let passed = 0;
  for (const item of tests) {
    try { await item.fn(); passed += 1; console.log(`✓ ${item.name}`); }
    catch (error) { console.error(`✗ ${item.name}`); console.error(error); process.exitCode = 1; }
  }
  console.log(`\n${passed}/${tests.length} testes aprovados.`);
})();

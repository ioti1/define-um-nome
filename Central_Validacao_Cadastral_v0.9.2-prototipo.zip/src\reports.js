(function (root, factory) {
  const U = typeof module === "object" && module.exports ? require("./utils.js") : root.CVCUtils;
  const Config = typeof module === "object" && module.exports ? require("./config.js") : root.CVCConfig;
  const api = factory(U, Config);
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.CVCReports = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function (U, Config) {
  "use strict";

  function kpi(label, value, note, tone) {
    return `<div class="report-kpi ${tone || ""}"><span>${U.escapeHtml(label)}</span><strong>${U.escapeHtml(value)}</strong><small>${U.escapeHtml(note || "")}</small></div>`;
  }
  function brand(negative) {
    return `<div class="report-brand"><img src="assets/petros-horizontal${negative ? "-negative" : ""}.png" alt="Petros"><span>Cadastro · Núcleo Analytics</span></div>`;
  }
  function reportBars(fieldStats) {
    return `<div class="report-bars">${fieldStats.slice(0, 9).map((item) => `<div><span>${U.escapeHtml(item.label)}</span><i><b style="width:${Math.max(2, item.recordConformity * 100)}%"></b></i><strong>${U.formatPercent(item.recordConformity, 1)}</strong></div>`).join("")}</div>`;
  }
  function issueTable(issues) {
    const top = issues.slice(0, 14);
    if (!top.length) return '<div class="report-success-box">Nenhuma inconsistência ou ressalva foi identificada com as regras selecionadas.</div>';
    return `<table class="report-table"><thead><tr><th>Linha</th><th>Matrícula</th><th>Campo / regra</th><th>Achado</th></tr></thead><tbody>${top.map((item) => `<tr><td>${item.rowNumber}</td><td>${U.escapeHtml(item.matricula || "—")}</td><td><strong>${U.escapeHtml(item.field)}</strong><small>${U.escapeHtml(item.rule)}</small></td><td><span class="report-severity ${item.severity}">${item.severity === "error" ? "Erro" : "Alerta"}</span>${U.escapeHtml(item.message)}</td></tr>`).join("")}</tbody></table>${issues.length > top.length ? `<p class="report-limit">Amostra de ${top.length} achados. O Excel de tratamento contém os ${U.formatNumber(issues.length)} achados.</p>` : ""}`;
  }

  function render(state) {
    const result = state.result;
    if (!result) return "";
    const summary = result.summary;
    const matriculaByRow = new Map(result.records.map((record) => [record.rowNumber, record.matricula]));
    const issues = result.issues.map((item) => Object.assign({}, item, { matricula: matriculaByRow.get(item.rowNumber) || "" }));
    const issueFields = result.fieldStats.filter((item) => item.affectedRecords);
    const mainFinding = summary.invalid
      ? `${U.formatNumber(summary.invalid)} registro(s) exigem tratamento antes do uso operacional.`
      : summary.withWarnings
        ? `Não há erros impeditivos; ${U.formatNumber(summary.withWarnings)} registro(s) precisam de revisão.`
        : "Todos os registros passaram sem erros ou alertas nas regras selecionadas.";
    return `<article class="report-document" id="printableReport">
      <section class="report-cover">
        ${brand(true)}
        <div class="report-cover-copy"><p class="report-eyebrow">RELATÓRIO EXECUTIVO</p><h1>Consistência<br>Cadastral</h1><h2>${U.escapeHtml(state.file?.name || "Arquivo processado")}</h2><p>Validação local orientada pelo Catálogo de Campos Cadastrais v${Config.CATALOG_VERSION}. Escopo configurado pelo usuário no momento do processamento.</p></div>
        <div class="report-cover-summary">${kpi("Registros", U.formatNumber(summary.total), "processados")}${kpi("Sem erros", U.formatPercent(summary.passRate, 1), `${U.formatNumber(summary.approved)} registros`)}${kpi("Inconsistentes", U.formatNumber(summary.invalid), "tratamento necessário", "danger")}${kpi("Regras", U.formatNumber(summary.selectedRules), `${summary.mappedFields} campos`)}</div>
        <footer>${Config.INTERNAL_NOTICE} · Gerado em ${U.nowLabel()}</footer>
      </section>
      <section class="report-page">
        <header>${brand(false)}<span>Visão executiva</span></header>
        <h2>Resultado da consistência</h2>
        <div class="report-overview"><strong>${U.escapeHtml(mainFinding)}</strong><span>Aprovação significa ausência de erro impeditivo nas regras locais selecionadas; alertas permanecem visíveis para revisão.</span></div>
        <div class="report-summary">${kpi("Consistentes", U.formatNumber(summary.consistent), U.formatPercent(summary.cleanRate, 1))}${kpi("Com ressalvas", U.formatNumber(summary.withWarnings), "sem erro impeditivo", "warning")}${kpi("Inconsistentes", U.formatNumber(summary.invalid), "com pelo menos 1 erro", "danger")}${kpi("Achados", U.formatNumber(summary.issueCount), `${summary.errorCount} erros · ${summary.warningCount} alertas`)}</div>
        <div class="report-grid"><section><h3>Conformidade por campo</h3>${reportBars(result.fieldStats)}</section><section><h3>Pontos de atenção</h3><ul class="report-findings">${issueFields.length ? issueFields.slice(0, 6).map((item) => `<li><strong>${U.escapeHtml(item.label)}</strong><span>${U.formatNumber(item.affectedRecords)} registro(s) afetado(s); conformidade de ${U.formatPercent(item.recordConformity, 1)}.</span></li>`).join("") : "<li><strong>Sem pontos críticos</strong><span>Nenhum campo apresentou quebra nas regras aplicadas.</span></li>"}</ul></section></div>
        <div class="report-method"><strong>Escopo auditável</strong><span>${summary.mappedFields} campos mapeados, ${summary.selectedRules} regras selecionadas e ${summary.skippedCount} avaliações não aplicáveis ou sem dependência disponível.</span></div>
        <footer class="report-end">PETROS · ${Config.INTERNAL_NOTICE} · Página 2</footer>
      </section>
      <section class="report-page report-detail-page">
        <header>${brand(false)}<span>Achados prioritários</span></header>
        <h2>Registros para revisão</h2>
        <p class="report-lead">A tabela apresenta uma amostra priorizada. O arquivo Excel de tratamento preserva a base completa, os valores originais, as sugestões e colunas de acompanhamento.</p>
        ${issueTable(issues.sort((a, b) => (a.severity === b.severity ? b.weight - a.weight : a.severity === "error" ? -1 : 1)))}
        <div class="report-method"><strong>Limite da validação local</strong><span>Controles documentais, integrações com RFB/IBGE/INSS, bases legais e vigências oficiais permanecem identificados no dicionário, mas não são simulados como aprovados sem fonte externa.</span></div>
        <footer class="report-end">PETROS · ${Config.INTERNAL_NOTICE} · Página 3</footer>
      </section>
    </article>`;
  }

  function print() {
    document.body.dataset.printReport = "true";
    const cleanup = () => { delete document.body.dataset.printReport; };
    window.addEventListener("afterprint", cleanup, { once: true });
    requestAnimationFrame(() => requestAnimationFrame(() => window.print()));
    setTimeout(cleanup, 60000);
  }

  return { render, print };
});

const assert = require("node:assert/strict");
const Engine = require("../src/engine.js");

(async () => {
  const total = Number(process.env.CVC_VOLUME || 100000);
  const rows = Array.from({ length: total }, (_, index) => [String(index + 1).padStart(8, "0")]);
  const started = Date.now();
  const progress = [];
  const result = await Engine.process({
    rows,
    mapping: { matricula_petros: 0 },
    selection: { matricula_petros: ["required", "format", "spaces", "unique"] },
    firstDataRow: 2,
    chunkSize: 5000,
    onProgress: (item) => progress.push(item.percent)
  });
  const duration = (Date.now() - started) / 1000;
  assert.equal(result.summary.total, total);
  assert.equal(result.summary.invalid, 0);
  assert.equal(result.summary.issueCount, 0);
  assert.equal(progress.at(-1), 100);
  console.log(`✓ ${total.toLocaleString("pt-BR")} registros processados em ${duration.toFixed(2)} s, sem perda de linhas.`);
})().catch((error) => { console.error(error); process.exit(1); });


# De-Para

Guarde aqui arquivos de mapeamento, equivalências e comparações.

# Tabelas

Guarde aqui planilhas, dicionários de dados, catálogos e tabelas de códigos.

# HUB Cadastro v13

Portal local do Setor de Cadastro. Não usa servidor: o HTML, a configuração e a Base de Apoio funcionam juntos na mesma pasta.

Na Central de Aplicações, **Abrir** inicia a ferramenta diretamente em uma nova aba. **Detalhes** abre a ficha completa com documentação, ambiente, versão, segurança e histórico.

## Arquivos essenciais

- **HUB Cadastro v13.html** — aplicação principal;
- **hub-v13.css** — estilo visual;
- **hub-v13-admin.js** — administração segmentada;
- **hub-v13-portal.js** — links, documentos rápidos e consulta de notícias;
- **hub-v13-app-rail.css** e **hub-v13-app-rail.js** — faixa horizontal dos acessos rápidos;
- **hub-cadastro-config.js** — fonte compartilhada carregada automaticamente pelo HUB;
- **hub-cadastro-config.json** — espelho legível, backup e arquivo de importação;
- **Base de Apoio** — PDFs, Word, Excel, manuais e outros conteúdos exibidos na Central de Apoio.
- **assets** — panorama local do Rio; mantenha esta pasta junto ao HTML.

## Novo visual

Cabeçalho com a arte enviada pelo usuário, texto sobre área clara e composição limitada a 1920 px para evitar ampliação excessiva em monitores ultrawide. A transição já faz parte da imagem; não há curvas artificiais sobrepostas. O tema escuro tem base grafite, com textos claros e acentos azul-Petros.

Aplicações sem fotografias: ícone vetorial, nome, resumo em até duas linhas, situação e Abrir/Detalhes. Na visualização em cards, todos ficam em uma única linha horizontal; aplicações adicionais permanecem à direita, sem criar segunda linha e empurrar os painéis de notícias, links e documentos. A largura dos cards se adapta à tela. O resumo completo continua disponível em Detalhes. Produção, Homologação e Indisponível/Em desenvolvimento são situações configuradas pelo administrador, não um teste em tempo real da conexão.

Para navegar, use a barra horizontal, as setas ao lado dos filtros ou a roda do mouse sobre os cards. Na borda da faixa, a roda volta a rolar a página verticalmente. Trackpad e gesto horizontal no celular funcionam nativamente. Com foco na faixa, use as setas do teclado, Home/End e PageUp/PageDown. Não há avanço automático ao passar o mouse. As setas só aparecem quando há conteúdo fora da área visível; movimento reduzido desativa a rolagem suave. A visualização em lista permanece como alternativa, e busca/filtros reposicionam a faixa no início. O hero não foi alterado.

Os agentes voltaram às bolinhas fixas na lateral inferior esquerda: ao passar o mouse ou focar pelo teclado, mostram nome e subtítulo; clicar abre diretamente o agente em nova aba. A tela de todos os agentes continua disponível no menu de pontos do cabeçalho. Não há coluna lateral ocupando espaço dos cards. Busca, filtros, ordenação, favoritos, notícias, links e documentos rápidos foram preservados. Sem calendário, tarefas ou servidor.

As configurações existentes foram preservadas: nenhum link, agente, documento ou regra de publicação foi substituído. Para manter os caminhos relativos das aplicações, coloque o HTML, CSS, os dois scripts v13 e a pasta assets no mesmo diretório em que já ficam o HUB e seus arquivos de configuração. Se houver uma configuração publicada mais recente, mantenha seu JSON e JS atuais.

O novo banner está em **assets/rio-banner.png**, cópia da imagem fornecida. A imagem anterior permanece no pacote apenas como referência. Os ícones são vetoriais e funcionam offline.

A marca do canto superior esquerdo usa os PNGs fornecidos: **assets/logo-petros-claro.png** no tema claro e **assets/logo-petros-escuro.png** no escuro. A troca acompanha automaticamente o tema selecionado, inclusive ao reabrir o HUB. A largura é de 146 px no desktop e 120–128 px nas telas menores, sem texto ou símbolo desenhado por cima.

Mantenha o nome **hub-cadastro-config.js**. É esse arquivo que permite que cada pessoa abra o HUB e receba a configuração publicada sem selecionar nada.

## Configurar os novos quadros

O Admin possui seis seções: Aplicações, Agentes, Links úteis, Documentos rápidos, Central de Apoio e Notícias. Em Aplicações, o campo Rótulo curto define o resumo do card; quando vazio, o card usa a descrição existente. Detalhes extensos ficam na ficha. Links/documentos podem ter URL, arquivo local ou caminho relativo, ícone, descrição e ordem. Documentos também podem apontar a uma referência já cadastrada na Central de Apoio.

Use Publicar para todos: links, documentos e preferências de notícias entram no objeto portal do mesmo JSON/JS compartilhado. Os quadros começam vazios para não inventar atalhos da equipe. Nenhum usuário de consulta precisa selecionar JSON.

Depois de adotar a v13, faça as publicações administrativas por esta versão. Os administradores de versões antigas não conhecem os novos quadros e podem removê-los ao republicar uma configuração.

No cabeçalho, o menu de pontos abre Aplicações, Agentes, Apoio e Ajuda. A busca filtra aplicações; Enter ou Ctrl+K abre a busca global, incluindo referências e atalhos do painel. O sino leva ao quadro de notícias; a engrenagem abre o Admin.

## Notícias e acesso à internet

Por padrão, o navegador consulta diretamente os índices públicos da Agência Brasil sobre Previdência Social, Previdência Complementar, INSS e Aposentadoria. Títulos são filtrados por assunto, deduplicados e ordenados pela data publicada; o quadro exibe até três notícias, com fonte, data e hyperlink. Não significa as três últimas notícias de toda a internet.

As fontes verificadas permitem CORS para arquivos locais. Isso pode mudar, e rede corporativa pode bloquear o acesso. Sem internet ou em caso de falha, o quadro exibe a última consulta salva com identificação de cache, ou um estado vazio honesto no primeiro acesso. Consultas parciais também são identificadas. O cache é individual no navegador, separado da configuração compartilhada; dura 15 minutos antes de uma nova consulta no próximo acesso. O botão ↻ força atualização.

Notícias podem ser desativadas ou usar RSS/Atom HTTPS sem credenciais no Admin. A fonte personalizada também precisa permitir CORS. Nenhum servidor ou proxy foi criado. O HTML remoto não é inserido na tela; somente títulos, datas e links validados são renderizados. Não há notícias fictícias.

**E o G1?** Não é uma escolha editorial contra o G1. O RSS oficial de Economia (https://g1.globo.com/rss/g1/economia/) respondeu, mas não enviou o cabeçalho Access-Control-Allow-Origin nos testes com Origin:null. O navegador bloqueia sua leitura automática pelo HTML local. A Agência Brasil permitiu essa leitura. Fontes alternativas são possíveis se também liberarem CORS. O G1 pode ser aberto normalmente como link útil, mas não foi incluído na consulta automática nem foi criado um proxy para contornar a restrição. Cabeçalhos e políticas podem mudar.

## Verificações desta entrega

Testados sintaxe e integração dos scripts/IDs, leitura da configuração anterior, serialização JSON/JS, isolamento dos formulários, autenticação e seleção de seção, busca/filtros, cards e abertura em nova aba. O quadro de notícias passou por 21 testes com fixtures (parsing, datas, ordem, URLs, cache, indisponibilidade e concorrência). A revisão v13 acrescentou 8 grupos de testes para dock, cards, integridade dos arquivos e regras responsivas de 360 a 3440 px. Foram verificados 11 novos pares sólidos de cores, além dos 32 pares anteriores, com contraste de texto mínimo de 4,5:1. Isso não mede cada pixel da fotografia.

A faixa horizontal passou por 10 grupos adicionais com 0, 1, 7 e 30 cards, navegando por setas/teclado/roda, limites, filtros, lista, mudanças de tamanho e movimento reduzido. Foi confirmada a preservação exata do hero, CSS principal, Admin, portal e configuração. Esses testes usam código e DOM simulado, não uma página renderizada.

As fontes da Agência Brasil retornaram HTTP 200 e CORS * em testes de rede com Origin:null; o RSS do G1 retornou 200 sem esse cabeçalho. Isso não elimina restrições específicas da rede de cada usuário. A inspeção visual em navegador nesta sessão foi limitada pelo bloqueio de automação a file://; testes de código e de contraste não substituem essa etapa.

## Publicar alterações

1. Abra o HTML e entre no **Admin**.
2. Edite Aplicações ou a Central de Apoio.
3. Clique em **Publicar para todos**.
4. No primeiro uso administrativo, selecione esta pasta — a mesma que contém o HTML.

O HUB grava e confere **hub-cadastro-config.json** e **hub-cadastro-config.js** em conjunto. Nos próximos usos, o navegador tenta reutilizar a autorização.

## Atualizar a Base de Apoio

1. Copie os arquivos para as subpastas de **Base de Apoio**.
2. No Admin, abra **Central de Apoio** e clique em **Indexar pasta de apoio**.
3. Revise o catálogo e clique em **Publicar para todos**.

Somente o administrador autoriza a pasta. Quem consulta o HUB recebe o índice pelo arquivo JS e não precisa selecionar documentos ou diretórios.

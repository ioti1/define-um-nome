/* Administração segmentada. A publicação continua no JSON e JS compartilhados. */
function requestPortalAdminSection(mode){
  const nextMode = ['apps','agents','links','documents','support','news'].includes(mode) ? mode : 'apps';
  if(adminModal.classList.contains('authenticated') && adminBackdrop.classList.contains('open')){
    setAdminMode(nextMode,true);
    return;
  }
  openAdmin();
  state.requestedAdminMode = nextMode;
}

function collectCurrentAdminDraft(validate){
  if(!adminModal.classList.contains('authenticated')) return null;
  if(state.adminMode === 'apps') return collectAdminAppDraft();
  if(state.adminMode === 'support') return supportConfig.resources.length ? collectReferenceAdminDraft(!!validate) : true;
  if(state.adminMode === 'agents'){
    aiAgents = collectAdminAgents();
    return aiAgents;
  }
  return collectPortalAdminDraft();
}

function portalShortcutIconOptions(selected){
  return Object.keys(icons).map(key => '<option value="' + h(key) + '"' + (key === selected ? ' selected' : '') + '>' + h(iconLabel(key)) + '</option>').join('');
}

function renderPortalAdmin(mode){
  const labels = {
    agents:['Agentes de IA','Configure os assistentes exibidos na lateral. Cada agente tem seu próprio acesso.'],
    links:['Links úteis','Atalhos do painel inicial. Adicione, edite ou reorganize os endereços utilizados pela equipe.'],
    documents:['Documentos rápidos','Destaque os arquivos mais utilizados. A Central de Apoio continua reunindo o catálogo completo.'],
    news:['Notícias','A consulta é automática quando há internet. A configuração é compartilhada; o conteúdo vem da fonte selecionada.']
  };
  const label = labels[mode] || labels.links;
  document.getElementById('portalAdminSectionTitle').textContent = label[0];
  document.getElementById('portalAdminSectionHint').textContent = label[1];
  document.getElementById('portalAgentsPanel').hidden = mode !== 'agents';
  document.getElementById('portalShortcutsPanel').hidden = !['links','documents'].includes(mode);
  document.getElementById('portalNewsPanel').hidden = mode !== 'news';
  document.getElementById('adminAddPortalItem').hidden = !['links','documents'].includes(mode);
  document.getElementById('adminAddPortalItem').textContent = mode === 'documents' ? 'Adicionar documento' : 'Adicionar link';
  if(mode === 'agents'){ renderAdminAgents(); return; }
  if(mode === 'news'){
    document.getElementById('adminNewsEnabled').value = String(portalConfig.news.enabled);
    document.getElementById('adminNewsMode').value = portalConfig.news.mode;
    document.getElementById('adminNewsSource').value = portalConfig.news.sourceLabel;
    document.getElementById('adminNewsFeed').value = portalConfig.news.feedUrl;
    document.getElementById('adminNewsKeywords').value = portalConfig.news.keywords;
    syncAdminNewsMode();
    return;
  }
  renderPortalShortcutRows(mode);
}

function renderPortalShortcutRows(mode){
  const entries = portalConfig[mode] || [];
  const host = document.getElementById('adminPortalItems');
  const documents = mode === 'documents';
  document.getElementById('portalShortcutsLegend').textContent = documents ? 'Documentos rápidos' : 'Links úteis';
  document.getElementById('portalDocumentsHint').hidden = !documents;
  const references = documents ? allSupportResources().filter(resource => resource.path) : [];
  host.innerHTML = entries.length ? entries.map((entry,index) => {
    const prefix = 'portal-' + mode + '-' + index;
    const selectedIcon = icons[entry.icon] ? entry.icon : documents ? 'document' : 'link';
    return '<div class="portal-edit-row form-grid" data-item-id="' + h(entry.id) + '">' +
      '<div class="form-field"><label for="' + prefix + '-title">Título</label><input class="portal-item-title" id="' + prefix + '-title" value="' + h(entry.title) + '" maxlength="100"></div>' +
      '<div class="form-field"><label for="' + prefix + '-icon">Ícone</label><select class="portal-item-icon" id="' + prefix + '-icon">' + portalShortcutIconOptions(selectedIcon) + '</select></div>' +
      '<div class="form-field full"><label for="' + prefix + '-description">Descrição curta</label><input class="portal-item-description" id="' + prefix + '-description" value="' + h(entry.description) + '" maxlength="180"></div>' +
      '<div class="form-field full"><label for="' + prefix + '-url">' + (documents ? 'Arquivo, caminho ou URL' : 'Endereço ou caminho') + '</label><input class="portal-item-url" id="' + prefix + '-url" value="' + h(entry.url) + '" placeholder="' + (documents ? './Base de Apoio/Documentos/manual.pdf' : 'https://...') + '"></div>' +
      (documents ? '<div class="form-field full"><label for="' + prefix + '-resource">Usar documento da Central de Apoio</label><select class="portal-item-resource" id="' + prefix + '-resource"><option value="">Caminho configurado acima</option>' + references.map(resource => '<option value="' + h(resource.id) + '"' + (entry.resourceId === resource.id ? ' selected' : '') + '>' + h(resource.title + ' — ' + resource.category) + '</option>').join('') + '</select></div>' : '') +
      '<div class="portal-row-actions form-field full"><button class="admin-action" type="button" data-portal-action="up" data-index="' + index + '"' + (index === 0 ? ' disabled' : '') + ' aria-label="Mover ' + h(entry.title || 'atalho') + ' para cima">↑ Subir</button><button class="admin-action" type="button" data-portal-action="down" data-index="' + index + '"' + (index === entries.length - 1 ? ' disabled' : '') + ' aria-label="Mover ' + h(entry.title || 'atalho') + ' para baixo">↓ Descer</button><button class="admin-action danger" type="button" data-portal-action="remove" data-index="' + index + '">Remover</button></div></div>';
  }).join('') : '<div class="admin-list-empty">Nenhum atalho configurado. Use “Adicionar ' + (documents ? 'documento' : 'link') + '” para começar.</div>';
  host.querySelectorAll('.portal-item-resource').forEach(select => select.addEventListener('change',() => {
    const row = select.closest('.portal-edit-row');
    const reference = references.find(resource => resource.id === select.value);
    if(!reference) return;
    row.querySelector('.portal-item-title').value = reference.title;
    row.querySelector('.portal-item-description').value = reference.description || '';
    row.querySelector('.portal-item-url').value = reference.path;
  }));
  host.querySelectorAll('.portal-item-url').forEach(input => input.addEventListener('input',() => {
    const selector = input.closest('.portal-edit-row').querySelector('.portal-item-resource');
    if(selector) selector.value = '';
  }));
}

function syncAdminNewsMode(){
  const custom = document.getElementById('adminNewsMode').value === 'rss';
  document.getElementById('adminNewsFeed').disabled = !custom;
  document.getElementById('adminNewsKeywords').disabled = !custom;
}

function collectPortalAdminDraft(){
  if(state.adminMode === 'news'){
    portalConfig.news = normalizePortal({news:{
      enabled:document.getElementById('adminNewsEnabled').value === 'true',
      mode:document.getElementById('adminNewsMode').value,
      sourceLabel:document.getElementById('adminNewsSource').value.trim(),
      feedUrl:document.getElementById('adminNewsFeed').value.trim(),
      keywords:document.getElementById('adminNewsKeywords').value.trim()
    }}).news;
    return portalConfig.news;
  }
  if(!['links','documents'].includes(state.adminMode)) return true;
  const items = [...document.querySelectorAll('#adminPortalItems .portal-edit-row')].map(row => ({
    id:row.dataset.itemId,
    title:row.querySelector('.portal-item-title').value.trim(),
    description:row.querySelector('.portal-item-description').value.trim(),
    url:row.querySelector('.portal-item-url').value.trim(),
    icon:row.querySelector('.portal-item-icon').value,
    resourceId:row.querySelector('.portal-item-resource')?.value || ''
  }));
  portalConfig[state.adminMode] = normalizePortal({[state.adminMode]:items})[state.adminMode];
  return portalConfig[state.adminMode];
}

function validatePortalConfig(){
  for(const kind of ['links','documents']){
    for(const [index,item] of portalConfig[kind].entries()){
      const reference = item.resourceId ? allSupportResources().find(resource => resource.id === item.resourceId) : null;
      const path = reference ? reference.path : item.url;
      if(!item.title || !safeResourceUrl(path)){
        return 'Preencha o título e um endereço válido no ' + (kind === 'links' ? 'link útil' : 'documento rápido') + ' nº ' + (index + 1) + '.';
      }
    }
  }
  if(portalConfig.news.enabled && portalConfig.news.mode === 'rss'){
    try{
      const feed = new URL(portalConfig.news.feedUrl);
      if(feed.protocol !== 'https:' || feed.username || feed.password) throw new Error('protocol');
    }catch(error){ return 'Informe uma URL HTTPS válida, sem credenciais, para o feed de notícias.'; }
  }
  return '';
}

async function saveCurrentAdminForm(){
  if(!adminModal.classList.contains('authenticated')) return;
  if(!collectCurrentAdminDraft(true)) return;
  const error = validatePortalConfig();
  if(error){ adminMessage.textContent = error; toast(error,'warn'); return; }
  await saveApps();
  renderAdmin();
  renderAgents();
  renderReferences();
  render();
}

document.getElementById('adminNewsMode').addEventListener('change',syncAdminNewsMode);
document.getElementById('adminAddPortalItem').addEventListener('click',() => {
  if(!['links','documents'].includes(state.adminMode)) return;
  collectPortalAdminDraft();
  portalConfig[state.adminMode].push({id:state.adminMode + '-' + Date.now() + '-' + Math.random().toString(36).slice(2,6),title:'',description:'',url:'',icon:state.adminMode === 'documents' ? 'document' : 'link',resourceId:''});
  saveAppsLocal();
  renderPortalShortcutRows(state.adminMode);
  const rows = document.querySelectorAll('#adminPortalItems .portal-edit-row');
  rows[rows.length - 1]?.querySelector('.portal-item-title').focus();
  adminMessage.textContent = 'Atalho adicionado nesta sessão. Preencha os dados e publique para todos.';
});
document.getElementById('adminPortalItems').addEventListener('click',event => {
  const button = event.target.closest('[data-portal-action]');
  if(!button || !['links','documents'].includes(state.adminMode)) return;
  collectPortalAdminDraft();
  const entries = portalConfig[state.adminMode];
  const index = Number(button.dataset.index);
  if(button.dataset.portalAction === 'remove') entries.splice(index,1);
  else{
    const target = index + (button.dataset.portalAction === 'up' ? -1 : 1);
    if(target < 0 || target >= entries.length) return;
    [entries[index],entries[target]] = [entries[target],entries[index]];
  }
  saveAppsLocal();
  renderPortalShortcutRows(state.adminMode);
  adminMessage.textContent = 'Organização alterada nesta sessão. Publique para compartilhar com a equipe.';
});
